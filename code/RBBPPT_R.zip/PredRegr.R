# Record Time Taken To Run Programme
etstr <- function(et) {
  dhms.sec <- c(60*60*24,60*60,60);
  dhms.str <- c("day", "hour", "minute")
  ets <- "Elapsed time:";
  etsi <- "";
  etr <- et[3];
  for (i in 1:3) {
    et.dhms <- etr%/%dhms.sec[i];
    etr <- etr%%dhms.sec[i];
	if (et.dhms > 1) {
	  dhms.str[i] <- paste(dhms.str[i],"s",sep="");
	}
	if (et.dhms > 0) {
	  if (i < 3) {
	    dhms.str[i] <- paste(dhms.str[i],",",sep="");		
	  } else {
	  	dhms.str[i] <- paste(dhms.str[i],"and",sep=" ");
	  }
	  etsi <- paste(etsi,et.dhms,dhms.str[i]);
	}
  }
  etsi <- paste(etsi,round(etr,2),"seconds.");
  ets <- paste(ets,etsi,sep="");
  return(ets);
}

ols <- function(y,x) {
	y <- as.matrix(y);
	x <- as.matrix(x);
	b <- solve(crossprod(x),crossprod(x,y));
	return(b);
}

# Matrix of lags (up to order p)
lgm <- function(y,p,trim=TRUE,add.y=FALSE) {
	n <- NROW(y);
	k <- NCOL(y);
	ly <- array(0,c(n,k*p));
	for (i in 1:p) {
		ly[(1+i):n,(i-1)*k+1:k] <- y[1:(n-i),];
	}
	ly <- ly[(1+trim*p):n,];
	if (add.y) {ly <- cbind(y[(p+1):n,],ly)}
	return(ly);
}

# First differences
dif <- function(y,trim=TRUE) {
	y <- as.matrix(y);
	ly <- lgm(y,1,FALSE);
	dy <- as.matrix(y - ly);
	dy <- dy[(1+trim):nrow(y),];
	return(as.matrix(dy));
}

# Reverse order statistics of a vector
order.stat <- function(x,k) {-sort(-x,partial=k)[k]}

# Modified function for AR series as a shell for "filter" to work on arrays
filter.array <- function(x,r) {
	x <- matrix(x,nrow=dim(x)[1]);
	y <- sapply(seq_len(NCOL(x)),function(i) filter(x[,i],c(r)[i],method="r"),simplify="array");
	return(y);
}

# Detrending of (possibly multivariate) time series
detr <- function(y,dc,cT=1) {
	T <- nrow(y);
	dcc <- ceiling((dc+1)/2);
	z <- cbind(1,1:T);
	zc <- dif(z,trim=FALSE) + cT*lgm(z,1,trim=FALSE);
	yc <- dif(y,trim=FALSE) + cT*lgm(y,1,trim=FALSE);
	z <- z[,1:dcc];
	zc <- zc[,1:dcc];
	b <- ols(yc,zc);
	x <- y - ceiling(dc/2)*z%*%b;
	return(as.matrix(x));
}

# Bartlett kernel
bartlett <- function(x) {
  y <- (1-abs(x))*(abs(x)<=1);
}

# j-th order (sub) covariance matrix
Cov.j <- function(x,j,s=1,e=NROW(x)) {
	n <- NROW(x);
	x <- matrix(x,nrow=n);
	return(t(x[(s+j):e-j,,drop=FALSE])%*%x[(s+j):e,,drop=FALSE]/n);
}

# Long run variance estimator (includes block bootstrap specific long-run variance estimator)
LRV <- function(u,k,h,boot=FALSE,l=h) {
	n <- NROW(u);
	Lambda <- matrix(0,nrow=NCOL(u),ncol=NCOL(u));
	if (boot) {
		Sigma <- Lambda;
		nb <- ceiling(n/l);
		if (l > 1) {
			for (i in 1:nb) {
				Sigma <- Sigma + Cov.j(u,0,(i-1)*l+1,min(i*l,n));
				for (j in 1:min(l-1,n-(i-1)*l-1)) {
					Lambda <- Lambda + Cov.j(u,j,(i-1)*l+1,min(i*l,n));
				}
			}
		} else {
			Sigma <- Cov.j(u,0);
		}
	} else {
		Sigma <- Cov.j(u,0);
		for (j in 1:h) {
			Lambda <- Lambda + Cov.j(u,j)*k(j/h);
		}
	}
	Omega <- Sigma + Lambda + t(Lambda);
	return(list(Omega,Lambda));
}

# Individual numerator, bias correction, denominator and variance correction of theta.i
test.parts.i <- function(z,dc,J,ibc=FALSE,boot=FALSE,l=J) {
	T <- NROW(z);
	k <- NCOL(z) - 1;
	z.d <- detr(z,dc);
	x.lag <- z.d[2:T-1,1:k+1,drop=FALSE];
	num.i <- matrix(crossprod(x.lag,z.d[2:T,]),nrow=k,ncol=k+1);
	denom.i <- crossprod(x.lag);
	v.hat <- z.d[2:T,1] - x.lag%*%solve(denom.i,num.i[,1]);
	w.hat <- matrix(nrow=T-1,ncol=k);
	for (i in 1:k) {
		w.hat[,i] <- z.d[2:T,i+1] - x.lag[,i]*solve(denom.i[i,i],num.i[i,i+1]);
	}
	LR.var <- LRV(cbind(v.hat,w.hat),bartlett,J,boot,l);
	
	if (ibc) {
		v.hat <- z.d[2:T,1] - x.lag%*%solve(denom.i,num.i[,1]-LR.var[[2]][1:k+1,1]);
		w.hat <- matrix(nrow=T-1,ncol=k);
		for (i in 1:k) {
			w.hat[,i] <- z.d[2:T,i+1] - x.lag[,i]*solve(denom.i[i,i],num.i[i,i+1]-LR.var[[2]][i+1,i+1]);
		}
		LR.var <- LRV(cbind(v.hat,w.hat),bartlett,J,boot,l);
	}
	return(list(num.i=num.i,denom.i=denom.i,LR.var.i=LR.var,z.x=list(z.d[2:T,],x.lag,z.d[1,])));
}

# Collect all individual test statistics parts
test.parts <- function(z,dc,J,ibc=FALSE,boot=FALSE,l=J) {
	z.list <- lapply(seq_len(dim(z)[2]),function(x) z[,x,]);
	return(lapply(z.list,FUN=test.parts.i,dc=dc,J=J,ibc=ibc,boot=boot,l=l));
}

# Individual unit test statistic and estimates
theta.i <- function(t.parts,T,k) {
	num.i <- t.parts[[1]][,1];
	denom.i <- t.parts[[2]];
	bias.i <- T*t.parts[[3]][[2]][1:k+1,1];
	var.i <- t.parts[[3]][[1]][1,1];
	if (k==1) {
		theta <- (num.i-bias.i)/sqrt(var.i*denom.i);
	} else {
		theta <- (num.i-bias.i)%*%solve(var.i*denom.i,num.i-bias.i);
	}
}

# Collect all theta_i statistics
theta.all <- function(t.parts,T,k) {
	theta <- sapply(t.parts,FUN=theta.i,T=T,k=k);
	return(theta);
}

# Individual unit test statistic and estimates
boot.input.i <- function(t.parts,T,k) {
	num.i <- t.parts[[1]];
	denom.i <- t.parts[[2]];
	bias.i <- T*t.parts[[3]][[2]][1:k+1,,drop=FALSE];
	z.d <- t.parts[[4]][[1]];
	x.lag <- t.parts[[4]][[2]];
	g.hat <- matrix(0,nrow=k,ncol=k+1);
	g.hat[,1] <- solve(denom.i,num.i[,1]-bias.i[,1]);
	for (i in 1:k) {
		g.hat[i,i+1] <- solve(denom.i[i,i],num.i[i,i+1]-bias.i[i,i+1]);
	}
	e <- z.d - x.lag%*%g.hat;
	return(list(eps.hat=e,rho.hat=diag(g.hat[,1:k+1,drop=FALSE])));
}

# Collect all theta.i, g.hat and e values for the bootstrap
boot.input <- function(t.parts,T,N,k) {
	boot.in <- lapply(t.parts,FUN=boot.input.i,T=T,k=k);
	rho.hat <- array(dim=c(N,k));
	e <- array(dim=c(T-1,N,k+1));
	for (i in 1:N) {
		e[,i,] <- boot.in[[i]][[1]];
		rho.hat[i,] <- boot.in[[i]][[2]];
	}
	return(list(eps.hat=e,rho.hat=rho.hat));
}

# Pooled test (tau.P)
tau.P <- function(t.parts,T,k) {
	all.num <- sapply(t.parts,function(x) x[[1]][,1]-T*x[[3]][[2]][1:k+1,1],simplify="array");
	all.denom <- sapply(t.parts,function(x) x[[2]]*x[[3]][[1]][1,1],simplify="array");
	if (k==1) {
		t.stat <- sum(all.num)/sqrt(sum(all.denom));
	} else {
		pooled.num <- apply(all.num,1,sum);
		pooled.denom <- apply(all.denom,c(1,2),sum);
		t.stat <- pooled.num%*%solve(pooled.denom,pooled.num);
	}
	return(t.stat);
}

# Group mean test (tau.GM)
tau.GM <- function(t.parts,T,k) {
	theta <- theta.all(t.parts,T,k);
	return(mean(theta));
}

# Moving Block Bootstrap series
MBB <- function(s,u,u.bm,l,r.boot,z.0) {
	u <- as.array(u);
	T <- dim(u)[1];
	N <- dim(u)[2];
	k <- dim(u)[3] - 1;
	nb <- ceiling(T/l);
	start.b <- sample.int(T-l+1,size=nb,replace=TRUE);
	u.star <- array(dim=c(nb*l+1,N,k+1));
	u.star[1,,] <- z.0;
	for (i in 1:nb) {
		index.i = 1:l + start.b[i] - 1;
		u.star[1:l+(i-1)*l+1,,] <- u[index.i,,,drop=FALSE] - u.bm;
	}
	u.star <- u.star[0:T+1,,,drop=FALSE];
	x.star <- filter.array(u.star[,,1:k+1,drop=FALSE],r.boot);
	y.star <- u.star[,,1];
	return(array(c(y.star,x.star),dim=c(T+1,N,k+1)));
}

# Panel bootstrap procedure
bootstrap <- function(B,u,rho.hat,z.0,dc,l,J,ibc=FALSE,boot.var=TRUE) {
	T <- dim(u)[1];
	N <- dim(u)[2];
	k <- dim(u)[3] - 1;
	if (l > 1) {
		u.bm <- aperm(array(colMeans(lgm(matrix(u,nrow=T,ncol=N*(k+1)),l-1,add.y=TRUE)),dim=c(N,k+1,l)),c(3,1,2));
	} else {
		u.bm <- array(apply(u,c(2,3),mean),c(1,N,k+1));
	}
	z.star <- lapply(seq_len(B),FUN=MBB,u=u,u.bm=u.bm,l=l,r.boot=rho.hat,z.0=z.0);
	t.parts.star <- lapply(z.star,FUN=test.parts,dc=dc,J=J,ibc=ibc,boot=boot.var,l=l);
	return(t.parts.star);
}

# Single step in the sequential testing procedure
BSQT.step <- function(j,p.vec,theta.i,ranks,t.star) {
	p.0 <- p.vec[j];
	p.1 <- p.vec[j+1];
	S.x <- ranks[0:p.0+1];
	rank.j <- ranks[p.1+1]-1;
	theta.j <- theta.i[rank.j+1];
	theta.star <- apply(t.star[,-S.x,drop=FALSE],1,order.stat,k=p.1-p.0);
	p.val.j <- mean(theta.star>theta.j);
	return(c(p.H0=p.0,p.H1=p.1,unit=rank.j,theta=theta.j,p.val=p.val.j));
}

# Sequential Testing Procedure (tau.SQ)
BSQT <- function(p.vec,theta.i,t.star,a,parallel=FALSE,nc=0) {
	N <- length(theta.i);
	ranks <- c(1,order(abs(theta.i),decreasing=TRUE) + 1);
	theta.i <- c(0,theta.i);
	t.star <- cbind(0,abs(t.star));
	if (p.vec[1] > 0) {
		p.vec <- c(0,p.vec);
	}
	if (p.vec[length(p.vec)] < N) {
		p.vec <- c(p.vec,N);
	}
	K <- length(p.vec) - 1;
	if (parallel){
		if (nc==0) {nc <- detectCores()}
		cl <- makeCluster(nc);
		clusterExport(cl=cl,varlist=ls(globalenv()));
		K.cl <- ceiling(K/nc);
		step.stats <- parSapply(cl,1:K,FUN=BSQT.step,p.vec,abs(theta.i),ranks,t.star,simplify="array");
		stopCluster(cl);
	} else {
		step.stats <- sapply(1:K,FUN=BSQT.step,p.vec,abs(theta.i),ranks,t.star,simplify="array");
	}
	p.hat <- p.vec[step.stats[5,]>a][1];
	if (p.hat>0) {S.x <- (0:N)[ranks[1:p.hat+1]]} else {S.x <- NULL}
	return(list(p.hat=p.hat,S.x=S.x,Steps.Details=t(step.stats)));
}

# Bootstrap Predictability Tests (shell for the three tests)
Bootstrap.Pred.Tests <- function(y,x,test=c("tau.P","tau.GM","tau.SQ"),lvl=0.05,p.vec=0:NCOL(y),B=999,dc=1,J=round(1.75*NROW(y)^(1/3)),l=round(1.75*NROW(y)^(1/3)),it.bc=FALSE,boot.var=TRUE,parallel=FALSE,nc=0) {
	start.time <- proc.time();
	T <- NROW(y);
	N <- NCOL(y);
	k <- NCOL(x)/NCOL(y);
	z <- array(c(y,x),dim=c(T,N,k+1));
	t.parts <- test.parts(z,dc,J,it.bc,boot.var,l);
	z.0 <- t(sapply(seq_len(N),function(x) t.parts[[x]][[4]][[3]],simplify="array"));
	boot.in <- boot.input(t.parts,T,N,k);
	test.out <- vector(mode="list",length=length(test)+1);
	names(test.out) <- c(test,"running.time");
	if (parallel){
		library(parallel);
		if (nc==0) {nc <- detectCores()}
		cl <- makeCluster(nc);
		clusterSetRNGStream(cl, sample.int(2^20,size=1));
		clusterExport(cl=cl,varlist=ls(globalenv()));
		B.cl <- ceiling(B/nc);
		t.parts.star.cl <- parLapply(cl,rep(B.cl,nc),fun=bootstrap,u=boot.in[[1]],rho.hat=boot.in[[2]],z.0=z.0,dc=dc,l=l,J=J,ibc=ibc,boot.var=boot.var);
		stopCluster(cl);
		t.parts.star <- vector("list",nc*B.cl);
		for (i in 1:nc) {
			t.parts.star[B.cl*(i-1)+1:B.cl] <- t.parts.star.cl[[i]];
		}
		t.parts.star <- t.parts.star[1:B];
	} else {
		t.parts.star <- bootstrap(B,boot.in[[1]],boot.in[[2]],z.0,dc,l,J,boot.var);
	}
	for (i in 1:length(test)) {
		if (grepl("SQ",test[i])) {
			theta <- theta.all(t.parts,T,k);
			t.star <- t(sapply(t.parts.star,theta.all,T=T,k=k,simplify="array"));
			test.out[[test[i]]] <- BSQT(p.vec,theta,t.star,lvl,parallel,nc);
		} else {
			test.stat <- c(do.call(test[i],list(t.parts=t.parts,T=T,k=k)));
			t.star <- sapply(t.parts.star,test[i],T=T,k=k);
			if (k==1) {
				p.val <- 2*min(mean(t.star>test.stat),mean(t.star<test.stat));
			} else {
				p.val <- mean(t.star>test.stat);
			}
			test.out[[test[i]]]<-list(test.stat=test.stat,p.val=p.val);
		}
	}
	test.out[[length(test)+1]] <- proc.time() - start.time;	
	return(test.out);
}
