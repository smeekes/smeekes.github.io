##################################################################################
#                                                                                #
# R code to perform block bootstrap panel predictability tests proposed in       #
#                                                                                #
# Smeekes, S. and J. Westerlund (2016). Robust Block Bootstrap Panel             #
#   Predictability Tests. GSBE Research Memorandum RM/13/060,                    #
#   Maastricht University.                                                       #
#                                                                                #
# Code by Stephan Smeekes (e-mail: S.Smeekes@maastrichtuniversity.nl)            #
#                                                                                #
# A description of the main function "Bootstrap.Pred.Tests" can be found below   #
#                                                                                #
##################################################################################

##################################################################################
#### function: Bootstrap.Pred.Tests ##############################################
##################################################################################
#### Block Bootstrap Panel Predictability Tests ##################################
##################################################################################
#### Description #################################################################
##################################################################################
#                                                                                #
# Bootstrap.Pred.Tests performs block bootstrap panel predictability tests as    #
# described in the paper                                                         #
#                                                                                #
# Smeekes, S. and J. Westerlund (2016). Robust Block Bootstrap Panel             #
#   Predictability Tests. GSBE Research Memorandum RM/13/060,                    #
#   Maastricht University.                                                       #
#                                                                                #
##################################################################################
#### Usage #######################################################################
##################################################################################
#                                                                                #
# Bootstrap.Pred.Tests(y, x, test = c("tau.P", "tau.GM", "tau.SQ"), lvl = 0.05,  #
#    p.vec = 0:NCOL(y), B = 999, dc = 1, J = round(1.75*NROW(y)^(1/3)),          #
#    l = round(1.75*NROW(y)^(1/3)), it.bc = FALSE, boot.var = TRUE,              #
#    parallel = FALSE, nc = 0)                                                   #
#                                                                                #
##################################################################################
#### Arguments ###################################################################
##################################################################################
#                                                                                #
# y         Data matrix of dimensions T times N containing the dependent         #
#           variables, that is, the variables that are tested to be predictable. #
# x         Data matrix of dimensions T times k*N containing the predictor       #
#           variables, where k is the number of predictor variables per unit.    #
#           In the paper, only k=1 is considered. The code extends this to k>1   #
#           by performing a Wald test rather than a t-test. The first N columns  #
#           should contian the first predictor for all N units, the next N       #
#           columns the second predictor for all units, and so on.               #
#           Note: Only performance with k=1 has been evaluated.                  #
# test      Which test statistic to use out of the pooled ("tau.P"), group-mean  #
#           ("tau.GM") and sequential ("tau.SQ") tests described in the paper.   #
#           Default is all three tests are conducted. Tests can be abbreviated   #
#           to "P", "GM" and "SQ".                                               #
# lvl       Significance level of the sequential test (the other tests return    #
#           p-values). Default is 0.05.                                          #
# p.vec     The vector of consecutive units to be tested for the sequential test #
#           tau.SQ. If the vector does not start with 0 (which is the first null #
#           hypothesis, or ends with N (the final alternative hypothesis), these #
#           will be added automatically. The defaults is the vector 0,1,2,...,N, #
#           which amounts to testing unit-by-unit.                               #
# B         Number of bootstrap replications. Default is 999.                    #
# dc        Deterministic specification: no deterministic components (0),        #
#           data are demeaned (0), or data are detrended (2). Default is 1.      #
# l         Block length used for the moving-block bootstrap. The default is     #
#           [1.75*T^(1/3))].                                                     #
# J         Bandwidth parameter for the variance estimation; the default is      #
#           [1.75*T^(1/3))], where T is the number of time series observations.  #
# it.bc     If TRUE, the long-run variance estimation and consequent bias        #
#           correction is performed iteratively. Default is FALSE.               #
# boot.var  If TRUE, the bootstrap-specific variance estimator is used within    #
#           the bootstrap algorithm. If FALSE, the same variance estimator       #
#           as for the sample is applied. Default is TRUE.                       #
# parallel  If TRUE, parallel computing from the package 'parallel' (part of the #
#           standard R distribution) is implemented using its 'parLapply'        #
#           functionality (available on all platforms including Windows). The    #
#           default is FALSE, such that no parallel computing is used.           #
# nc        Specifies the number of cores used for parallel computing. If set to #
#           0, R determines the number of cores and uses them all. Default is 0. #
#                                                                                #
##################################################################################
#### Value #######################################################################
##################################################################################
#                                                                                #
# Bootstrap.Pred.Tests returns a list with nested lists for each test, labeled   #
# as tau.P, tau.GM and $tau.SQ, plus an element running.time.                    #
#                                                                                #
# tau.P and tau.GM contain components test.stat, with the value of the test      #
# statistic, and p.val, its bootstrap p-value.                                   #
#                                                                                #
# tau.SQ contains p.hat, the number of predictable units, S.x, the set of        #
# predictable units, and Steps.Details, which is a matrix of dimensions K x 5,   #
# where the i-th row contains details for step i of the sequential procedure.    #
# It contains the number of predictable units under the null (p.H0), under the   #
# alternative (p.H1), the unit corresponding to the order statistic used (unit), #
# the test statistic (theta) and the bootstrap p-value (p.val).                  #
#                                                                                #
# running.time contains the running time of the function. Its output is          #
# identical to the output of system.time().                                      #
#                                                                                #
##################################################################################

# Call the functions in 'PredRegr.R'.
source("PredRegr.R");

# Load data: replace the simulated "y" and "x" with data of interest.
T <- 100; N <- 10; y <- array(rnorm(T*N),c(T,N)); x <- array(rnorm(T*N),c(T,N));

# Perform the test(s).
outp <- Bootstrap.Pred.Tests(y,x);
