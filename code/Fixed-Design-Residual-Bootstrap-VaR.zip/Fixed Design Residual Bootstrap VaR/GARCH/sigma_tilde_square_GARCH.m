function retval = sigma_tilde_square_GARCH(theta,epsilon)
    
    n = length(epsilon);

    sigma_tilde_square = zeros(n,1);
    
    sigma_tilde_square(1) = theta(1)/(1-theta(2)-theta(3));
    
    for t = 2:n
       sigma_tilde_square(t) =  theta(1) + theta(2)* (epsilon(t-1))^2 + theta(3)* sigma_tilde_square(t-1);
    end
    
    retval = sigma_tilde_square;

end