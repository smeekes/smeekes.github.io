function retval = L_tilde_GARCH(theta,epsilon,epsilon2)

    sigma_hat = sqrt(sigma_tilde_square_GARCH(theta,epsilon2));
    
   temp = -sum(l(epsilon,sigma_hat))/length(epsilon);
   
%    if (isnan(temp))
%         retval = 99999999;
%     else
%         retval = temp;
%     end

    if(isfinite(temp))
        retval = temp;
    else
        retval = 99999999;
    end
       
end
