function retval = l(x,sigma)

    retval = log(normpdf(x./sigma)./sigma);

end
