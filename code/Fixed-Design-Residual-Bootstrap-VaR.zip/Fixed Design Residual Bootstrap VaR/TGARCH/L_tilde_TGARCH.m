function retval = L_tilde_TGARCH(theta,epsilon,epsilon2)

    sigma_hat = sigma_tilde_TGARCH(theta,epsilon2);
    
   temp = -sum(l(epsilon,sigma_hat))/length(epsilon);

    if (isnan(temp))
        retval = 99999999;
    else
        retval = temp;
    end
       
end
