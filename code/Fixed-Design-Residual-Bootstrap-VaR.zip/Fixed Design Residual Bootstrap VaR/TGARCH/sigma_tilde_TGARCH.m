function retval = sigma_tilde_TGARCH(theta,epsilon)
    
    n = length(epsilon);

    sigma_tilde = zeros(n,1);
    
    sigma_tilde(1) = theta(1)/(1-theta(2)-theta(3)-theta(4));
    
    for t = 2:n
       sigma_tilde(t) =  theta(1) + theta(2)* max(epsilon(t-1),0) + theta(3)*max(-epsilon(t-1),0)+ theta(4)*sigma_tilde(t-1);
    end
    
    retval = sigma_tilde;

end