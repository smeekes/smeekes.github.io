%%%%A Residual Bootstrap for Conditional Value-at-Risk%%%%
%%%%Eric Beutner, Alexander Heinemann, Stephan Smeekes%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%TGARCH - Gaussian Simulations%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
close all;
clc;
clear;
 
seed = 9;
rng(seed);
 
%%%%%%%%%%%%%%%%%%%%
%%%Specifications%%%
%%%%%%%%%%%%%%%%%%%%
 
%sample size
n = 200;
 
%parameters
theta_true_1 = 0.05*20/sqrt(252);
theta_true_2 = 0.05; %0.1;
theta_true_3 = 0.1; %0.3;
theta_true_4 = 0.8; %0.55;
theta_true = [theta_true_1;theta_true_2;theta_true_3; theta_true_4]; 

alpha = [0.05;0.01];                       
xi_alpha = norminv(alpha);

sigma_inital = theta_true(1)/(1-theta_true(2)-theta_true(3)-theta_true(4));

gamma = [0.1;0.05];

%optimization settings
theta_start = [0.1;0.075;0.125;0.75]; %[0.1;0.125;0.325;0.5];
opt = optimset('Display','off', 'Algorithm', 'active-set');
lb = [0.0001;0.0001;0.0001;0.0001];
ub = [0.9999;0.9999;0.9999;0.9999];
A = [0,1,1,1];
c = 0.9999;


%%%%%%%%%%%%%%%%%%%%%
%%Simulation Set-up%%
%%%%%%%%%%%%%%%%%%%%%
 
S = 2000;
store_theta_hat_n = zeros(S,length(theta_true));
store_xi_hat_n_alpha = zeros(S,length(alpha));


B = 2000;
store_theta_hat_n_star = zeros(S,B,length(theta_true));
store_xi_hat_n_alpha_star = zeros(S,B,length(alpha));

store_VaR_hat_n_alpha = zeros(S,length(alpha));
store_VaR_n_alpha =  zeros(S,length(alpha));

count_lb_EP = 0;
count_ub_EP = 0;
count_lb_RT = 0;
count_ub_RT = 0;
count_lb_SY = 0;
count_ub_SY = 0;

length_sum_EP = 0;
length_sum_RT = 0;
length_sum_SY = 0;


parpool('local',feature('numcores'));
spmd
    rng(0,'combRecursive');
end
 
%start of simulations
tic;
parfor s = 1:S

    %set random number generator
        stream = RandStream.getGlobalStream();
        stream.Substream = s;
    
    %generate sample
        eta = randn(n,1); 
        sigma = zeros(n,1);
        epsilon = zeros(n,1); 
        sigma(1)= sigma_inital;
        epsilon(1) = sigma(1)*eta(1);
        for t = 2:n
           sigma(t) =  theta_true_1 + theta_true_2*max(epsilon(t-1),0)+ theta_true_3*max(-epsilon(t-1),0) + theta_true_4*sigma(t-1);
           epsilon(t) = sigma(t)*eta(t);
        end
    
    %Value-at-Risk
        VaR_n_alpha = -xi_alpha*(theta_true_1 + theta_true_2*max(epsilon(n),0)+ theta_true_3*max(-epsilon(n),0) + theta_true_4*sigma(n));
 
    %Two-step estimator
        [theta_hat_n,L_hat] = fmincon(@(theta) L_tilde_TGARCH(theta,epsilon,epsilon),theta_start,A,c,[],[],lb,ub,[],opt);
        
        sigma_hat = sigma_tilde_TGARCH(theta_hat_n,epsilon);
        eta_hat = epsilon./sigma_hat;
        xi_hat_n_alpha = quantile(eta_hat,alpha);

    %Value-at-Risk estimator
        VaR_hat_n_alpha = -xi_hat_n_alpha*(theta_hat_n(1) + theta_hat_n(2)*max(epsilon(n),0)+ theta_hat_n(3)*max(-epsilon(n),0) + theta_hat_n(4)*sigma_hat(n));
            
        %store results
        store_theta_hat_n(s,:) = theta_hat_n';
        store_xi_hat_n_alpha(s,:) = xi_hat_n_alpha';
        store_VaR_n_alpha(s,:) = VaR_n_alpha';
        store_VaR_hat_n_alpha(s,:) = VaR_hat_n_alpha';
    
     %Bootstrap set-up   
        temp_store_theta_hat_n_star = zeros(B,length(theta_true));
        temp_store_xi_hat_n_alpha_star = zeros(B,length(alpha));
        temp_store_VaR_hat_n_alpha_star = zeros(B,length(alpha));
    
    %start bootstrap    
        for b=1:B

            %generate bootstrap sample
                eta_star = eta_hat(unidrnd(n,n,1));
                epsilon_star = sigma_hat.*eta_star;

            %Two-step bootstrap estimator
                [theta_hat_n_star,L_hat_star] = fmincon(@(theta) L_tilde_TGARCH(theta,epsilon_star,epsilon),theta_hat_n,A,c,[],[],lb,ub,[],opt);

                eta_hat_star = epsilon_star./sigma_tilde_TGARCH(theta_hat_n_star,epsilon);
                xi_hat_n_alpha_star = quantile(eta_hat_star,alpha);                    

            %Bootstrap VaR estimator
                temp_store_VaR_hat_n_alpha_star(b,:) = -xi_hat_n_alpha_star'*(theta_hat_n_star(1) + theta_hat_n_star(2)*max(epsilon(n),0)+ theta_hat_n_star(3)*max(-epsilon(n),0) + theta_hat_n_star(4)*sigma_hat_star(n));

            %store results
                temp_store_theta_hat_n_star(b,:) = theta_hat_n_star';
                temp_store_xi_hat_n_alpha_star(b,:) = xi_hat_n_alpha_star';

        end
        
    %calculate bounds and coverage
        
        VaR_hat_mat = ones(B,1)*VaR_hat_n_alpha';
        
        %Option 1:
        VaR_lb_EP = VaR_hat_n_alpha*ones(1,length(gamma))-quantile((temp_store_VaR_hat_n_alpha_star-VaR_hat_mat),1-gamma/2)';
        VaR_ub_EP = VaR_hat_n_alpha*ones(1,length(gamma))-quantile((temp_store_VaR_hat_n_alpha_star-VaR_hat_mat),gamma/2)';
        count_lb_EP = count_lb_EP + (VaR_n_alpha*ones(1,length(gamma))<VaR_lb_EP);
        count_ub_EP = count_ub_EP + (VaR_n_alpha*ones(1,length(gamma))>VaR_ub_EP);
        length_sum_EP = length_sum_EP + (VaR_ub_EP-VaR_lb_EP);
        
        %Option 2:
        VaR_lb_RT = quantile(temp_store_VaR_hat_n_alpha_star,gamma/2)';
        VaR_ub_RT = quantile(temp_store_VaR_hat_n_alpha_star,1-gamma/2)';
        count_lb_RT = count_lb_RT + (VaR_n_alpha*ones(1,length(gamma))<VaR_lb_RT);
        count_ub_RT = count_ub_RT + (VaR_n_alpha*ones(1,length(gamma))>VaR_ub_RT);
        length_sum_RT = length_sum_RT + (VaR_ub_RT-VaR_lb_RT);
        
        %Option 3:
        VaR_lb_SY = VaR_hat_n_alpha*ones(1,length(gamma))-quantile(abs(temp_store_VaR_hat_n_alpha_star-VaR_hat_mat),1-gamma)';
        VaR_ub_SY = VaR_hat_n_alpha*ones(1,length(gamma))+quantile(abs(temp_store_VaR_hat_n_alpha_star-VaR_hat_mat),1-gamma)';
        count_lb_SY = count_lb_SY + (VaR_n_alpha*ones(1,length(gamma))<VaR_lb_SY);
        count_ub_SY = count_ub_SY + (VaR_n_alpha*ones(1,length(gamma))>VaR_ub_SY);
        length_sum_SY = length_sum_SY + (VaR_ub_SY-VaR_lb_SY);

        
    %store results    
        store_theta_hat_n_star(s,:,:) = temp_store_theta_hat_n_star;
        store_xi_hat_n_alpha_star(s,:,:) = temp_store_xi_hat_n_alpha_star;  
             
end

delete(gcp);

disp(datestr(datenum(0,0,0,0,0,toc),'HH:MM:SS'));

%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%Tables%%%%%%
%%%%%%%%%%%%%%%%%%%%%

for j = 1:length(gamma)
    
    for i = 1:length(alpha)
       
        fprintf('%.2f confidence interval for  %.2f Value-at-Risk',1-gamma(j),alpha(i));
        
        results = [(S-(count_lb_EP(i,j)+count_ub_EP(i,j)))/S, (S-(count_lb_RT(i,j)+count_ub_RT(i,j)))/S, (S-(count_lb_SY(i,j)+count_ub_SY(i,j)))/S; count_lb_EP(i,j)/S , count_lb_RT(i,j)/S, count_lb_SY(i,j)/S; count_ub_EP(i,j)/S , count_ub_RT(i,j)/S, count_ub_SY(i,j)/S; length_sum_EP(i,j)/S, length_sum_RT(i,j)/S, length_sum_SY(i,j)/S];
        display(results');
    end    
    
end


%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%Plots%%%%%%%
%%%%%%%%%%%%%%%%%%%%%

s = 123;

%theta_1 (=^ omega)
X1 =  sqrt(n)*(store_theta_hat_n(:,1) - theta_true(1));
Y1 = sqrt(n)*(store_theta_hat_n_star(s,:,1) - store_theta_hat_n(s,1));
xvar = linspace(min(min(X1),min(Y1)),max(max(X1),max(Y1)),40);
X1_density = ksdensity(X1,xvar);
Y1_density = ksdensity(Y1,xvar);
 
fig_1 = figure(1);
fig_1_plot = plot(xvar',X1_density','-',xvar',Y1_density','--');
set(fig_1_plot,'linewidth',3);
set(fig_1_plot,{'color'},{[0,0,0.6];[0,0.6,0]});
ylabel('Density','fontname','times','fontsize',18);
set(fig_1,'Color',[1 1 1]);
set(gca,'fontname','times','fontsize',18);
%xlim([-8,8]);
%ylim([0,0.22]);
 

%theta_2 (=^alpha^+)
X2 =  sqrt(n)*(store_theta_hat_n(:,2) - theta_true(2));
Y2 = sqrt(n)*(store_theta_hat_n_star(s,:,2) - store_theta_hat_n(s,2));
xvar = linspace(min(min(X2),min(Y2)),max(max(X2),max(Y2)),40);
X2_density = ksdensity(X2,xvar);
Y2_density = ksdensity(Y2,xvar);
 
fig_2 = figure(2);
fig_2_plot = plot(xvar',X2_density','-',xvar',Y2_density','--');
set(fig_2_plot,'linewidth',3);
set(fig_2_plot,{'color'},{[0,0,0.6];[0,0.6,0]});
ylabel('Density','fontname','times','fontsize',18);
set(fig_2,'Color',[1 1 1]);
set(gca,'fontname','times','fontsize',18);
%xlim([-3,3]);
%ylim([0,0.49]);


%theta_3 (=^alpha^-)
X3 =  sqrt(n)*(store_theta_hat_n(:,3) - theta_true(3));
Y3 = sqrt(n)*(store_theta_hat_n_star(s,:,3) - store_theta_hat_n(s,3));
xvar = linspace(min(min(X3),min(Y3)),max(max(X3),max(Y3)),40);
X3_density = ksdensity(X3,xvar);
Y3_density = ksdensity(Y3,xvar);
 
fig_3 = figure(3);
fig_3_plot = plot(xvar',X3_density','-',xvar',Y3_density','--');
set(fig_3_plot,'linewidth',3);
set(fig_3_plot,{'color'},{[0,0,0.6];[0,0.6,0]});
ylabel('Density','fontname','times','fontsize',18);
set(fig_3,'Color',[1 1 1]);
set(gca,'fontname','times','fontsize',18);
%xlim([-7,7]);
%ylim([0,0.24]);


%theta_4 (=^beta)
X4 =  sqrt(n)*(store_theta_hat_n(:,4) - theta_true(4));
Y4 = sqrt(n)*(store_theta_hat_n_star(s,:,4) - store_theta_hat_n(s,4));
xvar = linspace(min(min(X4),min(Y4)),max(max(X4),max(Y4)),40);
X4_density = ksdensity(X4,xvar);
Y4_density = ksdensity(Y4,xvar);
 
fig_4 = figure(4);
fig_4_plot = plot(xvar',X4_density','-',xvar',Y4_density','--');
set(fig_4_plot,'linewidth',3);
set(fig_4_plot,{'color'},{[0,0,0.6];[0,0.6,0]});
ylabel('Density','fontname','times','fontsize',18);
set(fig_4,'Color',[1 1 1]);
set(gca,'fontname','times','fontsize',18);
%xlim([-7,7]);
%ylim([0,0.24]);


%xi_alpha
for i=1:length(alpha)
    X5 =  sqrt(n)*(store_xi_hat_n_alpha(:,i) - xi_alpha(i));
    Y5 = sqrt(n)*(store_xi_hat_n_alpha_star(s,:,i) - store_xi_hat_n_alpha(s,i));
    xvar = linspace(min(min(X5),min(Y5)),max(max(X5),max(Y5)),40);
    X5_density = ksdensity(X5,xvar);
    Y5_density = ksdensity(Y5,xvar);

    fig_5 = figure(length(theta_true)+i);
    fig_5_plot = plot(xvar',X5_density','-',xvar',Y5_density','--');
    set(fig_5_plot,'linewidth',3);
    set(fig_5_plot,{'color'},{[0,0,0.6];[0,0.6,0]});
    ylabel('Density','fontname','times','fontsize',18);
    set(fig_5,'Color',[1 1 1]);
    set(gca,'fontname','times','fontsize',18);
    %xlim([-12,12]);
    %ylim([0,0.12]);
end