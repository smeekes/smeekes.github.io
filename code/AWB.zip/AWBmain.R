##########################################################################################
## ------------------------------------------------------------------------------------ ##
##                                                                                      ##
## This program contains R code to perform nonparametric trend estimation and to        ##
## obtain confidence intervals with the Autoregressive Wild Bootstrap as in:            ##
##                                                                                      ##
##  Friedrich, M., Smeekes, S. and J.-P. Urbain (2018). Autoregressive Wild             ##
##  Bootstrap Inference for Nonparametric Trends.                                       ##
##                                                                                      ##
## ------------------------------------------------------------------------------------ ##
##            Code by Marina Friedrich (friedrich@pik-potsdam.de)                       ##
## ------------------------------------------------------------------------------------ ##
##                                                                                      ##
## The main function "get.results" produces the nonparametric trend estimate as well as ##
## pointwise confidence intervals and simultaenous confidence bands.                    ##
##                                                                                      ##
## Bandwidth selection can be performed with the data-driven MCV criterion as described ##
## in the paper (Section 3.1).                                                          ##
## ------------------------------------------------------------------------------------ ##
##########################################################################################
## ------------------------------------------------------------------------------------ ##
##  FUNCTION     get.results(y,time,B,alpha,h,k,G=seq(1,length(y),1),C=0.5,l=4,         ##
##                   grid=seq(0.001, by=0.002, length.out=50))                          ##
## ------------------------------------------------------------------------------------ ##
##########################################################################################
## ------------------------------------------------------------------------------------ ##
##  Description of INPUT arguments:                                                     ##
## ------------------------------------------------------------------------------------ ##
##   y        Data vector of length n, containing the time series of interest           ##
##                                                                                      ##
##  time      A vector of length n, containing the corresponding dates in decimal       ##
##            format, which will have to be rescaled to range between 0 and 1 for       ##
##            nonparametric estimation (see Section 2)                                  ##
##                                                                                      ##
##   B        Number of bootstrap replication                                           ##
##                                                                                      ##
##  alpha     Nominal coverage of confidence intervals will be (1-alpha)                ##
##                                                                                      ##
##   h        Bandwidth parameter for nonparametric estimation, can be selected by      ##
##            the user or by a data-driven selection method, called Modified Cross      ##
##            Validation (MCV) and will be started by selecting "h=-1" with parameter   ##
##            l=4 and a grid [0.001,0.099] by default. Both can be changed by the user  ##
##                                                                                      ##
##   k        kernel function for nonparametric estimation, see available kernels below ##
##                                                                                      ##
##   G        set of time indices over which the confidence bands will be made          ##
##            simultaneous, with default being whole sample                             ##
##                                                                                      ##
##   C        parameter determining the extend of oversmoothing in Step 1 of the        ##
##            bootstrap algorithm, default is 0.5                                       ##
##                                                                                      ##
##   l        parameter for MCV, default equals 4                                       ##
##                                                                                      ##
##  grid      range of possible bandwidth for MCV, default being [0.001,0.099] in steps ##
##            of 0.002                                                                  ##
## ------------------------------------------------------------------------------------ ##
##########################################################################################
## ------------------------------------------------------------------------------------ ##
##  Description of OUTPUT:                                                              ##
## ------------------------------------------------------------------------------------ ##
##     m.hat          a vector of length n containing the trend estimate                ##
##                                                                                      ##
## confidence.pw      a n by 2 matrix containing pointwise confidence intervals,        ##
##                    the lower bounds in column 1 and the upper bounds in column 2     ##
##                                                                                      ##
## confidence.simu    a n by 2 matrix containing simultaneous confidence bands,         ##
##                    the lower bounds in column 1 and the upper bounds in column 2     ##
##                                                                                      ##
##    h.opt           the bandwidth used to perform the estimation                      ##
##                                                                                      ##
##     CV             the MCV criterion, which we recommend to plot, especially if the  ##
##                    largest value is chosen. It often contains a local minimum        ##
##                    at a lower value, which should then be chosen by adjusting the    ##
##                    grid accordingly                                                  ##
## ------------------------------------------------------------------------------------ ##
##########################################################################################
## ------------------------------------------------------------------------------------ ##
##  Available KERNEL functions: Epanechnikov, Uniform, Quartic, Cosine                  ##                                                        ##
## ------------------------------------------------------------------------------------ ##
##########################################################################################  

# Call the functions in 'AWBfunctions.R'.
source("AWBfunctions.R")

# Load data: replace the simulated "y" and "time" with data of interest,
# Missing data should be deleted from both vectors,
# "time" should be in decimal format (e.g. 2011.8) and then be rescaled using the formula:
# time <- (time-time[1])/(time[n]-time[1])
n <- 100; ar <- 0.1; ma <- 0.1; dat <- get.data(n,ar,ma);
y <- dat[[1]]
time <- dat[[2]]


# Choose bandwidth or, if data driven bandwidth method (MCV) is desired, set h to -1
h <- -1

# Additional arguments for the approach
B <- 999
alpha <- 0.05
k <- k.epanech

# Estimation and confidence bands
results <- get.results(y,time,B,alpha,h,k)
trend.est <- results[[1]]
CI.pw <- results[[2]]
CI.simu <- results[[3]]

# Bandwidth used for estimation, plots MCV criterion for visual inspection if desired
h.opt <- results[[4]]
CV <- results[[5]]
plot(CV[,1], CV[,2], type = "l")

# Print output, using "low" and "up" for suitable y-axis bounds
low <- -1
up <- 1
print.results(y,time,trend.est,CI.simu,low,up)
