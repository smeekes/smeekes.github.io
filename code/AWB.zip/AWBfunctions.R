##########################################################################################
## ------------------------------------------------------------------------------------ ##
##                                                                                      ##
## This program lists all functions needed for the Autoregressive Wild Bootstrap        ##
##             and nonparametric trend estimation as in the paper:                      ##
##                                                                                      ##
##  Friedrich, M., Smeekes, S. and J.-P. Urbain (2018). Autoregressive Wild             ##
##  Bootstrap Inference for Nonparametric Trends.                                       ##
##                                                                                      ##
## ------------------------------------------------------------------------------------ ##
##            Code by Marina Friedrich (friedrich@pik-potsdam.de)                       ##
## ------------------------------------------------------------------------------------ ##
##########################################################################################
## -------------------------------------------------------------------------------------##
## KERNEL functions for nonparametric estimation:                                       ##
## -------------------------------------------------------------------------------------##
## Uniform kernel
k.unif <- function(u){                                               
  bol <- abs(u) <= 1
  return (1/2*bol)
}

## Epanechnikov kernel 
k.epanech <- function(u){                                            
  bol <- abs(u) <= 1
  weight <- 3/4*(1-(u)^2)
  return (weight*bol)
}

## Quartic kernel
k.quartic <- function(u){                                            
  bol <- abs(u) <= 1
  weight <- 15/16*(1-(u)^2)^2
  return (weight*bol)
}

## Cosine kernel
k.cosine <- function(u){                                             
  bol <- abs(u) <= 1
  weight <- pi/4*cos((pi/2)*(u))
  return (weight*bol)
}

## ----------------------------------------------------------------------------------- ##
#########################################################################################
## ----------------------------------------------------------------------------------- ##
## MAIN functions for DGP, BANDWIDTH SELECTION and ESTIMATION:                         ##                                         ##
## ----------------------------------------------------------------------------------- ##
## Generate data as in our simulation study without missing data (homoskedastic case)
get.data <- function(n, ar, ma){
  p1 <- -1
  p2 <- 2.5
  location <- 0.9*n
  gamma <- 10
  ar.coef <- ar
  ma.coef <- ma
  t <- seq(1,n,1)
  eps <- rnorm((n+50),0,((1/4)*(1-ar.coef^2)/(1+ma.coef^2-2*ar.coef*ma.coef)))
  u <- arima.sim(list(ar = ar.coef, ma = ma.coef), (n+50), innov=eps)
  u <- u[51:(n+50)]
  y <- rep(0,n)
  beta1 <- rep(0,n)
  G <- function(t,gam,c) (1+exp((-1)*gam*(t-c)/n))^(-1)
  for (i in 1:n){
    beta1[i] <- p1*i/n + p2*i/n*G(t[i],gamma,location)
    y[i] <- beta1[i] + u[i]
  }
  time <- seq(1,n,1)/n
  return(list(y,time))
}


## Modified cross validation - bandwidth selection
MCV <- function(y,time,l,grid,k){
  dim <- length(grid)     
  CV <- rep(0, dim)
  n <- length(y)
  for (m in 1:dim){                                                  
    m.hat.llo <- rep(0,n)
    for (i in (1+l):(n-l-1)){          
      y.llo <-  y[-(i-l):-(i+l)]
      time.llo <- time[-(i-l):-(i+l)]   
      est <- LCEstimation(y.llo,time.llo,grid[m],k)
      m.hat.llo[i] <- est[i-l]
    }
    eps.tilde <- y - m.hat.llo
    eps.tilde[1:l] <- rep(0,l)
    eps.tilde[(n-l+1):n] <- rep(0,l)
    CV[m] <- (1/n)*sum(eps.tilde^2) 
  } 
  ind <- which.min(CV)
  h.opt <- grid[ind]
  return(list(h.opt,CV))
}

## default: Local constant nonparametric estimator
LCEstimation <- function(y,time,h,k){
  n <- length(y)
  diff <- outer(time,time,"-")/h
  k.diff <- do.call(k,list(diff))
  m.hat <- (k.diff %*% y)/rowSums(k.diff)
  return(m.hat)
}

## optional: Local linear nonparmetric estimator
LLEstimation <- function(y,time,h,k){
  n <- length(y) 
  m.hat <- rep(0,n)
  for (i in 1:n){
    diff <- (rep(time[i],n)-time)/h	
    ker <- do.call(k,list(diff))	                                                                                                        ## obtain estimate for every t=i/n
    zmatrix <- cbind(rep(1,n),rep(time[i],n)-time)
    bhat <- solve(t(zmatrix) %*% diag(ker) %*% zmatrix) %*% (t(zmatrix) %*% diag(ker) %*% y)
    m.hat[i] <-  bhat[1,]
  }
  return(m.hat)
}


## ---------------------------------------------------------------------------------- ##
########################################################################################
## ---------------------------------------------------------------------------------- ##
## MAIN functions BOOTSTRAP:                                                          ##
## ---------------------------------------------------------------------------------- ##

## generate matrix L to get the right dependence structure of the bootstrap errors with missing data
CholeskyDecomp <- function(time,theta,l){
  n <- length(time)
  gamma <- theta^(1/l)
  omega <- matrix(data=0, nrow=n, ncol=n)
  for (i in 1:n){
    for (j in i:n){
      if (i==j){
        omega[i,j] <- 0.5
      } else {
        omega[i,j] <- gamma^(time[j]-time[i])
      }
    }
  }
  omega <- omega + t(omega)
  L <- chol(omega)
  return(L)
}

## Autoregressive wild bootstrap
AWBootstrap <- function(y,m.tilde,B,h,est,L,time,k){
  n <- length(y)
  eps.hat <- y - m.tilde                                            
  m.hat.star <- matrix(data=0, nrow=n, ncol=B)
  for (b in 1:B){
    nu <- L%*%rnorm(n, mean=0, sd=1)                                  
    eps.star <- nu*eps.hat
    y.star <- m.tilde + eps.star
    m.hat.star[,b] <- LCEstimation(y.star,time,h,k)
  }
  return(m.hat.star)	
}

## obtain pointwise confidence intervals
pointwise.int <- function(y,m.hat,m.star,m.tilde,alpha,B){
  n <- length(y)
  diff.beta <- m.star - matrix(data=m.tilde, nrow=n, ncol=B)
  beta.sorted <- matrix(data=NA, nrow=n, ncol=B)
  intervals.beta <- matrix(data=NA, nrow=n, ncol=2)
  for (i in 1:n){
    beta.sorted[i,] <- sort(matrix(data=diff.beta[i,], nrow=1, ncol=B), decreasing=FALSE)
    
  }                                                                                      ## construction of the intervals for the d different betas
  intervals.beta[,1] <- matrix(data=m.hat, nrow=n, ncol=1) - matrix(data=beta.sorted[,ceiling((1-(alpha/2))*B)], nrow=n, ncol=1)
  intervals.beta[,2] <- matrix(data=m.hat, nrow=n, ncol=1) - matrix(data=beta.sorted[,ceiling((alpha/2)*B)], nrow=n, ncol=1)
  return(intervals.beta)
}


## obtain simultaneous confidence bands over the set G
simult.int <- function(y,m.hat,m.tilde,m.star,time,n.new,alpha,uniform,B,G,G.total){
  n <- length(y)	
  diff.beta <- m.star - matrix(data=m.tilde, nrow=n, ncol=B)
  beta.sorted <- matrix(data=NA, nrow=n, ncol=B)
  intervals.beta <- matrix(data=NA, nrow=n, ncol=2)
  for (i in 1:n){		
    beta.sorted[i,] <- sort(matrix(data=diff.beta[i,], nrow=1, ncol=B), decreasing=FALSE)
  }
  alpha.p <- 1/B                                                                              ## starting value for pointwise error
  count.b <- 1
  beta.quantiles <- matrix(data=NA, nrow=n, ncol=2*ceiling(alpha*B)-2) 
  while (alpha.p < alpha){                                                                    ## compute pointwise quantiles for every candidate alpha.p in the interval [1/B, alpha]
    beta.quantiles[,count.b] <- beta.sorted[,ceiling((alpha.p/2)*B)]                      ## lower quantile
    beta.quantiles[,count.b+1] <- beta.sorted[,ceiling((1-alpha.p/2)*B)]                  ## upper quantile
    count.b <- count.b + 2
    alpha.p <- alpha.p + 1/B
  }
  beta.count <- 0
  beta.total <- 0
  alpha.p <- 1/B
  beta.ratio <- matrix(data=NA, nrow=ceiling(alpha*B)-1, ncol=1)
  x <- 1                                                               ## to go through the quantiles in steps of size 2
  xx <- 1                                                              ## to store the ratios for ever candidate alpha.p
  xb <- 1                                                              ## to go through the beta.quantiles in steps of size 2 
  while (alpha.p < alpha){                                             ## determine, for every candidate alpha.p, the ratio of bootstrap curves around y.hat/beta.hat that fall in the corresponding band
    B.new <- B
    for (j in 1:B){
      G.number <- G.total
      for (k in 1:G.total){ 
        index <- which(time == (G[k]/n.new))
        if (length(index) == 0){
          G.number <- G.number - 1 
        }else{   
          if ((diff.beta[index,j] <= beta.quantiles[index,xb+1]) && (diff.beta[index,j] >= beta.quantiles[index,xb])){
            beta.count <- beta.count + 1
          } 
        }  
      }
      if (G.number == 0){
        B.new <- B.new - 1
      }else{			
        if (beta.count == G.number){
          beta.total <- beta.total + 1
        }
      }
      beta.count <- 0
    } 
    beta.ratio[xx] <- beta.total / B.new
    beta.total <- 0
    alpha.p <- alpha.p + 1/B
    x <- x + 2
    xx <- xx + 1
    xb <- xb + 2
  }
  if (B.new != 0){
    beta.difference <- matrix(data=NA, nrow=ceiling(alpha*B)-1, ncol=1)                                                ## obtain values of the beta.ratios closest to 1-alpha and position at which this is attained
    beta.confidence <- matrix(data=NA, nrow=n, ncol=2)
    beta.difference <- beta.ratio - (1-alpha)
    beta.min <- which.min(abs(beta.difference))
    beta.confidence[,1] <- m.hat - beta.quantiles[,(2*beta.min)]
    beta.confidence[,2] <- m.hat - beta.quantiles[,(2*beta.min-1)]
  }else{	
    beta.confidence <- matrix(data=NA, nrow=n, ncol=2)
  }	
  return(beta.confidence)
}

## main function to run the program
get.results <- function(y,time,B,alpha,h,k,G=seq(1,length(y),1),C=0.5,l=4, grid=seq(0.001, by=0.002, length.out=50)){
  n <- length(y)
  ## BANDWIDHT SELECTION
  if (h == -1){
    temp <- MCV(y,time,l,grid,k)
    h.opt <- temp[[1]]
    CV <- cbind(grid, temp[[2]])
  }else{
    h.opt <- h
  }
  h.tilde <- C*(h.opt)^(5/9)
  ## ESTIMATION AND CONFIDENCE INTERVALS 
  m.hat <- LCEstimation(y,time,h.opt,k)
  m.tilde <- LCEstimation(y,time,h.tilde,k)
  theta <- 0.01^(1/(1.75*n^(1/3))) 
  ell <- 1/365.25
  cho <- CholeskyDecomp(time,theta,ell)
  m.star <- AWBootstrap(y,m.tilde,B,h.opt,est,cho,time,k)
  confidence.pw <- pointwise.int(y,m.hat,m.star,m.tilde,alpha,B)
  G.total <- length(G)
  confidence.simu <- simult.int(y,m.hat,m.tilde,m.star,time,n,alpha,uniform,B,G,G.total)
  return(list(m.hat,confidence.pw,confidence.simu,h.opt,CV))
}

## prints trend estimate and CI, if desired
print.results <- function(y,time,m.hat,int.s,low,up){
  plot(time, y, type="p", ylim=c(low,up), col="grey", xlab="Date", ylab="Time series")
  par(new=T)
  plot(time, m.hat, type="l", lwd=1.5, ylim=c(low,up), col="black", xlab="Date", ylab="Time series")
  par(new=T)
  plot(time, int.s[,1], type="l", lwd=1.5, ylim=c(low,up), col="red", xlab="Date", ylab="Time series")
  par(new=T)
  plot(time, int.s[,2], type="l", lwd=1.5, ylim=c(low,up), col="red", xlab="Date", ylab="Time series")
}


