% This example code produces the WIMP confidence intervals based on the
% approach by Mountford and Uhlig (2009), as seen in Figure 9 in the
% paper. See 'SVAR_IR_WIMP_Signs.m' for a detailed explanation of the
% function, as well as its inputs and outputs.

% load data:
y=xlsread('data_1950_2006.xls')';
% take logs
xx=1:10;
xx(4)=[];
y(xx,:)=log(y(xx,:));

% specify input arguments:
p=4;
ict=1;
trd=1;
qtrd=0;
h=60;
alph=32;
boot=99;
SHOCKS=[1 3 8 9; %BC shock
          4 5 6 7; %MP shock
          3 nan nan nan];% GS shock
SIGNS=[1 1 1 1; % signs BC shock
         1 0 0 0; % signs MP shock
         1 nan nan nan];% signs tax-shock
NP=[4;4;4];% number of periods for shock identification
S=3;% Only select tax-shock

  


[LB,UB,IR,A_LB,A_UB,A_IR]=SVAR_IR_WIMP_Signs(y,p,h,boot,alph,ict,trd,qtrd,SIGNS,SHOCKS,NP,S);

% ordering of variables in the data set:
VARNAMES={'GDP','Government Spending','Taxes','Interest Rate','Reserves','Prices','Deflator','Consumption','Investment','Wages'};
% rearranging order for plots
ordering=[1 8 2 3 10 9 4 5 6 7];  

% normalization of shocks
n=max(IR(3,:));

% scale interest rate responses
IR(4,:)=IR(4,:)/100;
LB(4,:)=LB(4,:)/100;
UB(4,:)=UB(4,:)/100;
A_IR(4,:)=IR(4,:)/100;
A_LB(4,:)=LB(4,:)/100;
A_UB(4,:)=UB(4,:)/100;


% plot IRs
figure(1)
for i=1:size(y,1)
    subplot(5,2,i)
    plot(LB(ordering(i),:)/n,'k--','Linewidth',2.5)
    hold on
    plot(UB(ordering(i),:)/n,'k--','Linewidth',2.5)
    hold on
    plot(IR(ordering(i),:)/n,'k-','Linewidth',2.5)
    hold on
    title(VARNAMES(ordering(i)),'FontSize',12,'FontName','Lucida Sans Typewriter')
    axis('tight')
end

% plot Accumulated IRs
figure(2)
for i=1:size(y,1)
    subplot(5,2,i)
    plot(A_LB(ordering(i),:)/n,'k--','Linewidth',2.5)
    hold on
    plot(A_UB(ordering(i),:)/n,'k--','Linewidth',2.5)
    hold on
    plot(A_IR(ordering(i),:)/n,'k-','Linewidth',2.5)
    hold on
    title(VARNAMES(ordering(i)),'FontSize',12,'FontName','Lucida Sans Typewriter')
    axis('tight')
end