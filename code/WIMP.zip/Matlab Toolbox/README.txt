====================================================================================

== WIMP Toolbox for MATLAB ==

   Lenard Lieb and Stephan Smeekes
   Correspondence to: L.Lieb@maastrichtuniversity.nl

====================================================================================

This MATLAB toolbox provides functions to compute Weighted Inference by Model 
Plausibility (WIMP) intervals for impulse responses based on (structural) VAR models
with different identification schemes on the shocks, based on the paper

Lieb, L. and Smeekes, S. (2017). Inference for Impulse Responses under Model 
Uncertainty. GSBE Research Memorandum RM/17/xxx.

In addition, example codes and the data are provided with which the empirical WIMP 
confidence interval reported in the paper can be replicated.

====================================================================================

== CONTENTS ==

The toolbox contains the following files:
** MATLAB functions **
SVAR_IR_WIMP_Chol.m	
SVAR_IR_WIMP_FE.m
SVAR_IR_WIMP_Proxy.m
SVAR_IR_WIMP_Signs.m
** MATLAB code examples **
example_Chol.m
example_narrative.m
example_proxy.m
example_sign_restriction.m
** DATA **
data_1950_2006.xls
Mertens_shock_unant_1950_2006.xls
Ramey_shock_1950_2006.xls

The functionality of the MATLAB files is described in each of the files themselves.

====================================================================================

== INSTALLATION & USE ==

The most recent version of the toolbox can be downloaded from the website
http://researchers-sbe.unimaas.nl/stephansmeekes

Extract and save all files in the same folder. Open the desired file(s) in MATLAB. 
The examples can be run "as is" by pressing 'RUN' (F5) in MATLAB.

This code can make use of parallel computation resources. Depending on the Matlab 
version, manual activation of multiple cores may be required to enable this.

====================================================================================

This version: August 23, 2017

Copyright: Lenard Lieb and Stephan Smeekes

This program is free software: you can redistribute it and/or modify it so long as
original authorship credit is given and you in no way impinge on its free
distribution. This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY.

====================================================================================
====================================================================================
