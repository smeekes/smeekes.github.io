% This example code produces the WIMP confidence intervals based on the
% approach by Blanchard and Perotti (2002), as seen in Figure 7 in the
% paper. See 'SVAR_IR_WIMP_Chol.m' for a detailed explanation of the
% function, as well as its inputs and outputs.

% load data:
y=xlsread('data_1950_2006.xls')';
% take logs
xx=1:10;
xx(4)=[];
y(xx,:)=log(y(xx,:));

% specify input arguments:
p=4;
ict=1;
trd=1;
qtrd=0;
h=60;
alph=32;
boot=99;
s=1;

% rearrange data such that GS is ordered first:
y=[y(2,:);y(1,:);y(3:end,:)];
  
[LB,UB,IR,A_LB,A_UB,A_IR]=SVAR_IR_WIMP_Chol(y,p,h,s,boot,alph,ict,trd,qtrd);

% ordering of variables in the (rearranged) data set:
VARNAMES={'Government Spending','GDP','Taxes','Interest Rate','Reserves','Prices','Deflator','Consumption','Investment','Wages'};
% rearranging order for plots
ordering=[2 8 1 3 10 9 4 5 6 7];    

% normalization of shocks
n=max(IR(1,:));

% scale interest rate responses
IR(4,:)=IR(4,:)/100;
LB(4,:)=LB(4,:)/100;
UB(4,:)=UB(4,:)/100;
A_IR(4,:)=IR(4,:)/100;
A_LB(4,:)=LB(4,:)/100;
A_UB(4,:)=UB(4,:)/100;


% plot IRs
figure(1)
for i=1:size(y,1)
    subplot(5,2,i)
    plot(LB(ordering(i),:)/n,'k--','Linewidth',2.5)
    hold on
    plot(UB(ordering(i),:)/n,'k--','Linewidth',2.5)
    hold on
    plot(IR(ordering(i),:)/n,'k-','Linewidth',2.5)
    hold on
    title(VARNAMES(ordering(i)),'FontSize',12,'FontName','Lucida Sans Typewriter')
    axis('tight')
end

% plot Accumulated IRs
figure(2)
for i=1:size(y,1)
    subplot(5,2,i)
    plot(A_LB(ordering(i),:)/n,'k--','Linewidth',2.5)
    hold on
    plot(A_UB(ordering(i),:)/n,'k--','Linewidth',2.5)
    hold on
    plot(A_IR(ordering(i),:)/n,'k-','Linewidth',2.5)
    hold on
    title(VARNAMES(ordering(i)),'FontSize',12,'FontName','Lucida Sans Typewriter')
    axis('tight')
end