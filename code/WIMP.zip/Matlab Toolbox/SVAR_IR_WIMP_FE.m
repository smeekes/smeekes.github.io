%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This function computes WIMP confidence intervals for forecast error
% impulse responses, i.e. intervals for MA coefficients.
%
% This code can make use of parallel computation resources. Depending on
% the Matlab version, manual activation of multiple cores may be required
% to take advantage of this.
%
%
% Usage:
% [LB,UB,IR,A_LB,A_UB,A_IR]=
% SVAR_IR_WIMP_FE(y,p,h,s,boot,alph,ict,trd,qtrd)
%
% Name: SVAR_IR_WIMP_FE
%
%
% This version: August 2017
% 
% Copyright: Lenard Lieb and Stephan Smeekes
%
% This program is free software: you can redistribute it and/or modify
% it so long as original authorship credit is given and you in no way 
% impinge on its free distribution. This program is distributed in the hope 
% that it will be useful, but WITHOUT ANY WARRANTY.
%    
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% INPUT %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%% SPECIFICATION OF THE REDUCED-FORM VAR: %%%%%%%%%%%%%%%%%%
%
%   -> y -    a KxT dimensional data matrix containing the K-dimensional
%             time series observed from t=1,2,...,T
%   -> p -    lag-order of the VAR
%   -> ict -  Set ict=0 if model is estimated without an intercept and set
%             ict=1 when intercept is included.
%   -> trd -  Set trd=0 if model is estimated without a linear time trend
%             and set trd=1 when a linear time trend is included.
%   -> qtrd - Set trd=0 if model is estimated without a quadratic time
%             trend and set qtrd=1 when a quadratic time trend is included.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%% INFERENCE AND THE BOOTSTRAP %%%%%%%%%%%%%%%%%%%%%%%%
%
%   -> alph - significance level alpha for the confidence intervals (e.g.
%             1, 5, 10, or 32,...)
%   -> boot - number of bootstrap iterations, e.g. 999
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%% FE IMPULSE RESPONSES: %%%%%%%%%%%%%%%%%%%%%%%%%%
%
%   -> h - maximum response horizon considered
%   -> s - Forecast errors to a shock of unit size in variable s
%          (cooresponds to the s-th column of the MA coefficients)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% OUTPUT %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%   -> LB -    Kxh dimensional matrix of lower bounds of the confidence
%              intervals for the FE impulse responses
%   -> UB -    Kxh dimensional matrix of upper bounds of the confidence
%              intervals for the FE impulse responses
%   -> IR -    Model averaging estmator of the structural responses based
%              on the trace weights used for the WIMP intervals
%   -> A_LB -  Kxh dimensional matrix of lower bounds of the confidence
%              intervals for the FE accumulated impulse responses
%   -> A_UB -  Kxh dimensional matrix of upper bounds of the confidence
%              intervals for the FE accumulated impulse responses
%   -> A_IR -  Model averaging estmator of the FE accumulated
%              responses based on the trace weights used for the WIMP
%              intervals
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




function[LB,UB,IR,A_LB,A_UB,A_IR]=SVAR_IR_WIMP_FE(y,p,h,s,boot,alph,ict,trd,qtrd)

aa=0.5;
bb=1;

[LB,UB,A_UB,A_LB,IR,A_IR]=wimp(y,h,boot,p,aa,bb,alph,s,ict,trd,qtrd);


function[LB,UB,A_UB,A_LB,ir,a_ir]=wimp(y,h,boot,p,aa,bb,alph,s,ict,trd,qtrd)

%%% Demeaning, detrending,...
if ict==1 || trd==1 || qtrd==1
    XX=[ones(1,size(y,2))*ict;(1:size(y,2))*trd;((1:size(y,2)).^2)*qtrd];
    XX(~any(XX,2),:)=[];
    y=y-y*XX'*((XX*XX')\eye(size(XX,1)))*XX;
end

k=size(y,1);
T=size(y,2)-p;

[W,~,r_opt] = rank_weights(y,p,aa,bb);
W=W+ones(1,k+1)*1/(k+1);
W=W./sum(W)

R=0:k;

ir=zeros(k,h);
a_ir=zeros(k,h);

UBx=zeros(k,h,k+1);
LBx=zeros(k,h,k+1);
A_UBx=zeros(k,h,k+1);
A_LBx=zeros(k,h,k+1);
parfor rr=1:k+1
    
    [alpha, beta, gamma,~,U] = VECM_ML(y,p,R(rr));
    
    B=VECM2VAR(alpha,beta,gamma);
    
    [phi] = VAR2MA(B,p,h) ;
    
    ss=zeros(k,1);
    ss(s)=1;
    ir1=zeros(k,h);
    IR=zeros(k,h);
    for i=1:h
        IR(:,i)=phi(:,:,i)*ss;
        ir1(:,i)=phi(:,:,i)*ss;
    end
    A_IR=cumsum(IR')';
    ir=ir+W(rr)*ir1;
    a_ir=a_ir+W(rr)*A_IR;
    
    IR_boot=zeros(k,boot,h);
    A_IR_boot=zeros(k,boot,h);
    
    for b=1:boot
        [IR_boot(:,b,:),A_IR_boot(:,b,:)]=Boot_IRs(B,U,y,p,R(rr),h,k,IR,A_IR,s,ict,trd,qtrd);
    end
    
    UB1=zeros(k,h);
    LB1=zeros(k,h);
    
    A_UB1=zeros(k,h);
    A_LB1=zeros(k,h);
    
    for i=1:k
        
        UB1(i,:)=prctile(IR_boot(i,:,:),alph/2);
        LB1(i,:)=prctile(IR_boot(i,:,:),100-alph/2);
        
        
        A_UB1(i,:)=prctile(A_IR_boot(i,:,:),alph/2);
        A_LB1(i,:)=prctile(A_IR_boot(i,:,:),100-alph/2);
        
        
    end
    
    LBx(:,:,rr)=IR-LB1;
    UBx(:,:,rr)=IR-UB1;
    A_LBx(:,:,rr)=A_IR-A_LB1;
    A_UBx(:,:,rr)=A_IR-A_UB1;
    
    
end

[UB,LB]=weighting_intervalls(UBx,LBx,k,h,r_opt,W);

[A_UB,A_LB]=weighting_intervalls(A_UBx,A_LBx,k,h,r_opt,W);


function[UB,LB]=weighting_intervalls(UBx,LBx,k,h,r_opt,W)

UB=zeros(k,h);
LB=zeros(k,h);


for i=1:k
    for j=1:h
        
        
        UB_r_all=vec(UBx(i,j,:))';
        UB_r_opt=UBx(i,j,r_opt+1);
        UB_r=UB_r_all(UB_r_all>UB_r_opt);
        
        if isempty(UB_r)==1
            UB(i,j)=UB_r_opt;
        else
            remain_r=find(UB_r_all>UB_r_opt);
            remain_W=W(remain_r);
            UB(i,j)=max(diag(UB_r_opt+diag(abs(UB_r_all(remain_r)-UB_r_opt))*(diag(remain_W./W(r_opt+1)))));
        end
        
        
        LB_r_all=vec(LBx(i,j,:))';
        LB_r_opt=LBx(i,j,r_opt+1);
        LB_r=LB_r_all(LB_r_all<LB_r_opt);
        
        if isempty(LB_r)==1
            LB(i,j)=LB_r_opt;
        else
            remain_r=find(LB_r_all<LB_r_opt);
            remain_W=W(remain_r);
            LB(i,j)=min(diag(LB_r_opt-diag(abs(LB_r_all(remain_r)-LB_r_opt))*(diag(remain_W./W(r_opt+1)))));
        end
        
    end
    
end


function[IR_boot,A_IR_boot]=Boot_IRs(B,U,y,p,r,h,k,IR,A_IR,s,ict,trd,qtrd)

IR_boot=zeros(k,h);
IR_boot1=zeros(k,h);

[y_boot] = resid_boot_series(B,U,y,ict,trd,qtrd);
[alpha_boot, beta_boot, gamma_boot,Cov] = VECM_ML(y_boot,p,r);

B_boot=VECM2VAR(alpha_boot,beta_boot,gamma_boot);

[phi_boot] = VAR2MA(B_boot,p,h);

ss=zeros(k,1);
ss(s)=1;
for i=1:h
    IR_boot1(:,i)=phi_boot(:,:,i)*ss;
    IR_boot(:,i)=phi_boot(:,:,i)*ss - IR(:,i);
end

A_IR_boot=cumsum(IR_boot1')'-A_IR;


function [phiB] = VAR2MA(B,p,h)

K = size(B,1);


B1=[B;eye((p-1)*K) zeros((p-1)*K,K)];
JB=[eye(K) zeros(K,(p-1)*K)];
phiB(:,:,1)=eye(K);

for j=1:h
    phiB(:,:,j)=JB*(B1^(j-1))*JB';
end


function [vek] = vec(X)
vek=X(:);


function[Z]=regressor_matrix(y,p)

n=size(y,2);
k=size(y,1);

Z=zeros(k*p,n);

for i=1:p
    Z(((i-1)*k+1):(i*k),(1+i):n) = y(:,1:(n-i));
end
Z=Z(:,(1+p):n);


function [alpha, beta, gamma, Cov, U] = VECM_ML(y,p,r)
warning off

% Defining Data Matrices:
y_lag = y(:,1:end-1);
y_diff = y(:,2:end) - y(:,1:end-1);

if r > 0
    
    if p==1
        
        r0 = y_diff;
        r1 = y_lag;
        n = length(y_diff);
        
    else
        
        Z_diff = regressor_matrix(y_diff,p-1);
        y_lag(:,1:p-1) = [];
        y_diff(:,1:p-1) = [];
        n = length(y_diff);
        
        % Constructing projection Matrix
        M = eye(n) - Z_diff'*( (Z_diff*Z_diff')\eye(size(Z_diff*Z_diff',1)) )*Z_diff;
        r0 = y_diff*M;
        r1 = y_lag*M;
        
    end
    
    
    %%% Likelihood estimation: %%%
    
    % Construct eigenvalues and corresponding (ordered eigenvectors:
    s00 = r0*r0'/n;
    s01 = r0*r1'/n;
    s10 = r1*r0'/n;
    s11 = r1*r1'/n;
    
    % inverse square root
    [v_s11,e_s11] = eig(s11);
    s11_sr_inv = ( (v_s11*sqrt(e_s11)*v_s11')\eye(size(v_s11*sqrt(e_s11)*v_s11',1)) );
    
    s00_inv = s00\eye(size(s00,1));
    
    b = s11_sr_inv*s10*s00_inv*s01*s11_sr_inv;
    
    [ev,eva] = eigs(b,r);
    
    % Maximizers of the log likelihood
    
    % 1.) Cointegration matrix:
    betaNI = (ev'*s11_sr_inv)';
    
    % Normalize beta for consistent estimation:
    if r>1
        
        beta_first = betaNI(1:r,:);
        beta_last = betaNI*( beta_first\eye(size(beta_first,1)) );
        beta_last(1:r,:)=[];
        beta = [eye(r);beta_last];
        
    else
        
        beta_first = betaNI(1);
        beta_last = betaNI*(1/beta_first);
        beta_last(1:r) = [];
        beta = [1;beta_last];
        
    end
    
    % 2.) Short-run parameters:
    alpha = s01*beta*( (beta'*s11*beta)\eye(size(beta'*s11*beta,1)) );
    
    if p>1
        
        gamma = (y_diff-alpha*beta'*y_lag)*Z_diff'*( (Z_diff*Z_diff')\eye(size(Z_diff*Z_diff',1)) );
        
        U = y_diff - alpha*beta'*y_lag - gamma*Z_diff;
        
    else
        
        gamma = [];
        
        U = y_diff - alpha*beta'*y_lag;
        
    end
    
    Cov = U*U'/n;
    
else
    
    [gamma,Cov,U] = VAR_LS(y_diff, p-1);
    
    k=size(y_diff,1);
    
    alpha=zeros(k,k);
    beta=zeros(k,k);
    
end


function [W1,W2,r1,r2,W1x,W2x] = rank_weights(y,p,aa,bb)

K=size(y,1);

% Defining Data Matrices:
y_lag = y(:,1:end-1);
y_diff = y(:,2:end) - y(:,1:end-1);


if p==1
    
    r0 = y_diff;
    r1 = y_lag;
    T = length(y_diff);
    
else
    
    Z_diff = regressor_matrix(y_diff,p-1);
    y_lag(:,1:p-1) = [];
    y_diff(:,1:p-1) = [];
    T = length(y_diff);
    
    % Constructing projection Matrix
    M = eye(T) - Z_diff'*( (Z_diff*Z_diff')\eye(size(Z_diff*Z_diff',1)) )*Z_diff;
    r0 = y_diff*M;
    r1 = y_lag*M;
    
end


%%% Constructing Likelihood %%%

% Construct eigenvalues and corresponding (ordered eigenvectors:
s00 = r0*r0';
s01 = r0*r1';
s10 = r1*r0';
s11 = r1*r1';

% inverse square root
[v_s11,e_s11] = eig(s11);
s11_sr_inv = ( (v_s11*sqrt(e_s11)*v_s11')\eye(size(v_s11*sqrt(e_s11)*v_s11',1)) );

s00_inv = s00\eye(size(s00,1));

b = s11_sr_inv*s10*s00_inv*s01*s11_sr_inv;


%%% Calculating Weights: %%%

sort_eigs=ones(K,1)-sort(abs(eig(b)),'descend');

W1(1)=exp(-bb*T^(-aa)*(-T*sum(log(sort_eigs(1:K)))));
W2(1)=exp(-bb*T^(-aa)*(-T*(log(sort_eigs(1)))));
W1a(1)=W1(1);
W2a(1)=W2(1);
for i=2:K+1
    if i<=K
        W1a(i)=exp(-bb*T^(-aa)*(-T*sum(log(sort_eigs(i:K)))));
        W2a(i)=exp(-bb*T^(-aa)*(-T*(log(sort_eigs(i)))));
    else
        W1a(i)=1;
        W2a(i)=1;
    end
    
    W1(i)=W1a(i)-W1a(i-1);
    W2(i)=W2a(i)-W2a(i-1);
    
end

W1x=W1;
W2x=W2;

W1=W1./sum(W1);
W2=W2./sum(W2);

r1=find(W1==max(W1))-1;
r2=find(W2==max(W2))-1;

W1=W1./sum(W1);
W2=W2./sum(W2);


function [B] = VECM2VAR(alpha,beta,gamma)

K=size(alpha,1);

if isempty(gamma)==1
    p=1;
else
    p=size(gamma,2)/K+1;
end

J=[eye(K) zeros(K,(p-1)*K)];
W=([J;kron(ones(p-1,1)',eye(K))' kron(-triu(ones(p-1,p-1),0)',eye(K))])^(-1);

if p>1
    B = [alpha*beta' gamma]*W+J;
else
    B = alpha*beta'+eye(K);
end


function [y_boot] = resid_boot_series(B,U,y,ict,trd,qtrd)

k=size(B,1);
p=size(B,2)/k;
T=size(y,2)-p;

U = U-diag(mean(U,2))*ones(size(U,1),size(U,2));

y_boot(:,1:p)=y(:,1:p);

for i=p+1:T+p
    
    randy = randsample([1:T],1);
    
    y_boot(:,i) = B*vec(fliplr(y_boot(:,(i-p:i-1)))) + U(:,randy);%U(:,i)*randn;
    
end

if ict==1 || trd==1 || qtrd==1
    XX=[ones(1,size(y,2))*ict;(1:size(y,2))*trd;((1:size(y,2)).^2)*qtrd];
    XX(~any(XX,2),:)=[];
    y_boot=y_boot-y_boot*XX'*((XX*XX')\eye(size(XX,1)))*XX;
end


function[B,Cov,U]=VAR_LS(y, p)

n = size(y,2)-p;

k = size(y,1);

% Regressand
Y = y(:,p+1:end);

% Regressor
Z = regressor_matrix(y,p);


% LS Estimation
B = Y*Z'*((Z*Z')\eye(k*p));

U = Y - B*Z;

Cov = U*U'/n;