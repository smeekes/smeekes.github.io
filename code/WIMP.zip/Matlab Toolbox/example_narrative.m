% This example code produces the WIMP confidence intervals based on the
% approach by Ramey (2011), as seen in Figure 8 in the
% paper. See 'SVAR_IR_WIMP_Chol.m' for a detailed explanation of the
% function, as well as its inputs and outputs.

% load data:
y=xlsread('data_1950_2006.xls')';
% take logs
xx=1:10;
xx(4)=[];
y(xx,:)=log(y(xx,:));
% load proxy TS
x=xlsread('Ramey_shock_1950_2006.xls')';

% specify input arguments:
p=4;
ict=1;
trd=1;
qtrd=0;
h=60;
alph=32;
boot=99;
s=1;
y=[x;y];

  
[LB,UB,IR,A_LB,A_UB,A_IR]=SVAR_IR_WIMP_Chol(y,p,h,s,boot,alph,ict,trd,qtrd);
IR(1,:)=[];
LB(1,:)=[];
UB(1,:)=[];
A_IR(1,:)=[];
A_LB(1,:)=[];
A_UB(1,:)=[];

% ordering of variables in the data set:
VARNAMES={'GDP','Government Spending','Taxes','Interest Rate','Reserves','Prices','Deflator','Consumption','Investment','Wages'};
% rearranging order for plots
ordering=[1 8 2 3 10 9 4 5 6 7];  

% normalization of shocks
n=max(IR(2,:));

% scale interest rate responses
IR(4,:)=IR(4,:)/100;
LB(4,:)=LB(4,:)/100;
UB(4,:)=UB(4,:)/100;
A_IR(4,:)=IR(4,:)/100;
A_LB(4,:)=LB(4,:)/100;
A_UB(4,:)=UB(4,:)/100;


% plot IRs
figure(1)
for i=1:size(y,1)-1
    subplot(5,2,i)
    plot(LB(ordering(i),:)/n,'k--','Linewidth',2.5)
    hold on
    plot(UB(ordering(i),:)/n,'k--','Linewidth',2.5)
    hold on
    plot(IR(ordering(i),:)/n,'k-','Linewidth',2.5)
    hold on
    title(VARNAMES(ordering(i)),'FontSize',12,'FontName','Lucida Sans Typewriter')
    axis('tight')
end

% plot Accumulated IRs
figure(2)
for i=1:size(y,1)-1
    subplot(5,2,i)
    plot(A_LB(ordering(i),:)/n,'k--','Linewidth',2.5)
    hold on
    plot(A_UB(ordering(i),:)/n,'k--','Linewidth',2.5)
    hold on
    plot(A_IR(ordering(i),:)/n,'k-','Linewidth',2.5)
    hold on
    title(VARNAMES(ordering(i)),'FontSize',12,'FontName','Lucida Sans Typewriter')
    axis('tight')
end