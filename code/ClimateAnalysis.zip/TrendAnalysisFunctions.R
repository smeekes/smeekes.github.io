##########################################################################################
## ------------------------------------------------------------------------------------ ##
##                                                                                      ##
## This program lists all functions needed for the trend analysis tools described       ##
##                 in the paper:                                                        ##
##                                                                                      ##
##  Bader, W., Beutner, E., Franco, B., Friedrich, M., Lejeune, B., Mahieu, E.,         ##
##  Reuvers, H., Smeekes, S., Urbain, J.-P. (2019). Nonparametric estimation and        ##
##  bootstrap inference on trends in atmospheric time series: an application to ethane. ##
##                                                                                      ##
## ------------------------------------------------------------------------------------ ##
##            Code by Marina Friedrich (friedrich@pik-potsdam.de)                       ##
## ------------------------------------------------------------------------------------ ##
##########################################################################################
## -------------------------------------------------------------------------------------##
## Auxiliary functions:                                                                 ##
## -------------------------------------------------------------------------------------##
## Uniform kernel
k.unif <- function(u){                                               
  bol <- abs(u) <= 1
  return (1/2*bol)
}

## Epanechnikov kernel 
k.epanech <- function(u){                                            
  bol <- abs(u) <= 1
  weight <- 3/4*(1-(u)^2)
  return (weight*bol)
}

## Quartic kernel
k.quartic <- function(u){                                            
  bol <- abs(u) <= 1
  weight <- 15/16*(1-(u)^2)^2
  return (weight*bol)
}

## Cosine kernel
k.cosine <- function(u){                                             
  bol <- abs(u) <= 1
  weight <- pi/4*cos((pi/2)*(u))
  return (weight*bol)
}

## generate matrix L to get the right dependence structure of the bootstrap errors with missing data
cholesky.decomp <- function(time,theta,l){
  n <- length(time)
  gamma <- theta^(1/l)
  omega <- matrix(data=0, nrow=n, ncol=n)
  for (i in 1:n){
    for (j in i:n){
      if (i==j){
        omega[i,j] <- 0.5
      } else {
        omega[i,j] <- gamma^(time[j]-time[i])
      }
    }
  }
  omega <- omega + t(omega)
  L <- chol(omega)
  return(L)
}

## return bootstrap errors given a residual series
awb <- function(resid,time){
  n <- length(time)
  th <- 0.01^(1/ (1.75*n^(1/3)))
  l <- 1/365.25
  L <- cholesky.decomp(time,th,l)
  nu <- L%*%rnorm(n,mean=0, sd=1)
  eps.star <- nu*resid
  return(eps.star)
}

## ----------------------------------------------------------------------------------- ##
#########################################################################################
## ----------------------------------------------------------------------------------- ##
## Functions for (broken) linear trend estimation (Section 3):                         ##                                         
## ----------------------------------------------------------------------------------- ##

## obtain regressor matrix for trend with one break (at given date) and Fourier terms 
regressors <- function(breakdate,time,terms){
  if (terms==0){
    x.matrix <- matrix(data=0, nrow=length(time),ncol=3)
    iter <- 0
  }else{
    x.matrix <- matrix(data=0, nrow=length(time),ncol=2*terms+3)
    for (iter in 1:terms){
      x.matrix[,(2*(iter-1)+1)] <- cos(2*pi*iter*time)
      x.matrix[,(2*iter)] <- sin(2*pi*iter*time)
    }
  }
  x.matrix[,(2*iter+1)] <- rep(1,length(time))
  x.matrix[,(2*iter+2)] <- time
  ind <- time > breakdate
  x.matrix[,(2*iter+3)] <- (time-breakdate)*ind
  return(x.matrix)
}

## fit linear trend without break (with Fourier terms)
fit.trend <- function(y,time,terms){
  reg <- regressors(0,time,terms)
  reg <- reg[,(1:(2*terms+2))]
  para <- solve(t(reg)%*%reg)%*%t(reg)%*%y
  reg.fit <- reg%*%para
  trend.fit <- reg[,(2*terms+1):(2*terms+2)]%*%para[(2*terms+1):(2*terms+2),]
  resid <- y - reg.fit
  SSR <- t(resid)%*%resid
  return(list(para,reg.fit,SSR,trend.fit))
}

## fit a linear trend with one break at given date (with Fourier terms)
fit.break <- function(y,time,breakdate,terms){
  diff <- time-breakdate
  date <- which.min(abs(diff))
  reg <- regressors(breakdate,time,terms)
  para <- solve(t(reg)%*%reg)%*%t(reg)%*%y
  reg.fit <- reg%*%para
  res <- y - reg.fit
  SSR <- t(res) %*% res
  trend.fit <- reg[,(2*terms+1):(2*terms+3)]%*%para[(2*terms+1):(2*terms+3),]
  intercept <- para[2*terms+1]
  slope1 <- para[2*terms+2]
  slope2 <- para[2*terms+3]
  intercept2 <- intercept - time[date]*slope2
  para.transform <- rep(0,2*terms+4)
  para.transform[1:(2*terms)] <- para[(1:(2*terms)),1]
  para.transform[(2*terms+1):(2*terms+4)] <- c(intercept,intercept2,slope1,(slope1+slope2))
  return(list(para,para.transform,reg.fit,SSR,trend.fit))
}

## locate one break in the data
get.break <- function(y,time,terms,trim.frac){
  n <- length(y)
  trim <- n*trim.frac
  i.1 <- 1+trim
  i.2 <- n - trim
  len <- i.2-i.1+1
  SSR <- rep(0,len)
  for (i in 1:len){
    c.break <- i.1+(i-1)
    SSR[i] <- fit.break(y,time,time[c.break],terms)[[4]]
  }
  min.ind <- i.1 + which.min(SSR) - 1
  min.val <- min(SSR)
  return(list(time[min.ind],min.val))
}

## obtain the test statistic S_T from equation (3.5)
break.teststat <- function(y,time,terms,trim.frac){
  SSR <- fit.trend(y,time,terms)[[3]]
  break.reg <- get.break(y,time,terms,trim.frac)
  break.date <- break.reg[[1]]
  SSR.break <- break.reg[[2]]
  S <- SSR - SSR.break
  return(list(S,SSR))
}

## bootstrap algorithm for the break test (Algorithm 2)
break.bootstrap <- function(y,time,terms,B,trim.frac){
  n <- length(time)
  trend <- fit.trend(y,time,terms)[[2]]
  resid <- y - trend
  S.star <- rep(0,B)
  for (b in 1:B){
    eps.star <- awb(resid,time)
    y.star <- trend + eps.star
    S.star[b] <- break.teststat(y.star,time,terms,trim.frac)[[1]]
  }
  S.sorted <- sort(S.star, decreasing = FALSE)
  return(S.sorted)
}

## testing procedure: 1 break vs. no break (equation (3.5) + Algorithm 2)
breaktest <- function(y,time,terms,B,alpha,trim.frac){
  temp <- break.teststat(y,time,terms,trim.frac)
  S <- temp[[1]]
  S.boot <- break.bootstrap(y,time,terms,B,trim.frac)
  p.value <- mean(S.boot>rep(S,B))
  critical.value <- S.boot[ceiling((1-alpha)*B)]
  return(list(p.value,critical.value,S))
}

## bootstrap to obtain CI around the break location (Algorithm 1)
location.bootstrap <- function(y,time,trend.fit,terms,B,alpha,trim.frac){
  n <- length(time)
  resid <- y - trend.fit
  T.star <- rep(0,B)
  for (b in 1:B){
    eps.star <- awb(resid,time)
    y.star <- trend.fit + eps.star
    T.star[b] <- get.break(y.star,time,terms,trim.frac)[[1]]
  }
  T.sorted <- sort(T.star, decreasing = FALSE)
  low <- T.sorted[ceiling(alpha*B)]
  up <- T.sorted[ceiling((1-alpha)*B)]
  return(list(low,up))
}


## bootstrap to obtain CI around parameter estimates
para.bootstrap <- function(y,time,trend.fit,para,breakdate,terms,B,alpha,trim.frac){
  n <- length(time)
  resid <- y - trend.fit
  if (breakdate == 0){
    rows <- 2*terms+2
  }else{
    rows <- 2*terms+4
  }
  paradiff.star <- matrix(data=NA, nrow=rows, ncol=B)
  for (b in 1:B){
    y.star <- trend.fit + awb(resid,time)
    if (breakdate == 0){
      paradiff.star[,b] <- fit.trend(y.star,time,terms)[[1]]-para
    }else{
      paradiff.star[,b] <- fit.break(y.star,time,breakdate,terms)[[2]]-para
    }
  }
  paradiff.sorted <- matrix(data=NA, nrow=rows, ncol=B)
  for (i in 1:rows){		
    paradiff.sorted[i,] <- sort(matrix(data=paradiff.star[i,], nrow=1, ncol=B), decreasing=FALSE)
  }
  up <- matrix(data=paradiff.sorted[,ceiling((1-(alpha/2))*B)], nrow=rows, ncol=1)
  low <- matrix(data=paradiff.sorted[,ceiling((alpha/2)*B)], nrow=rows, ncol=1)
  return(list(para-up,para-low))
}

## main function to run the linear trend estimation (with break testing)
lin.trend <- function(y,time,B,alpha, terms=3, trim.frac=0.1){
  test <- breaktest(y,time,terms,B,alpha,trim.frac)
  p <- test[[1]]
  cv <- test[[2]]
  S_T <- test[[3]]
  if (p < 0.05){
    breakpoint <- get.break(y,time,terms,trim.frac)[[1]]
    break.reg <- fit.break(y,time,breakpoint,terms)
    para <- break.reg[[2]]
    fit <- list(break.reg[[3]],break.reg[[5]])
    CI <- location.bootstrap(y,time,break.reg[[3]],terms,B,alpha,trim.frac)
    CI.low <- CI[[1]]
    CI.up <- CI[[2]]
    CI.para <- para.bootstrap(y,time,break.reg[[3]],para,breakpoint,terms,B,alpha,trim.frac)
    CI.para.low <- CI.para[[1]]
    CI.para.up <- CI.para[[2]]
  }else{
    breakpoint <- 0
    trend.reg <- fit.trend(y,time,terms)
    para <- trend.reg[[1]]
    fit <- list(trend.reg[[2]],trend.reg[[4]])
    CI.para <- para.bootstrap(y,time,trend.reg[[2]],para,breakpoint,terms,B,alpha,trim.frac)
    CI.para.low <- CI.para[[1]]
    CI.para.up <- CI.para[[2]]
    CI.low <- 0
    CI.up <- 0
  }
  return(list(p,cv,S_T,para,fit,breakpoint,c(CI.low,CI.up),c(CI.para.low,CI.para.up)))
}

print.results.linear <- function(y,time,fit,breakdate,CI.break,low,up,xlabel,ylabel){
  plot(time,y,type="p",lwd=1.5,ylim=c(low,up),col="grey",ylab=ylabel,xlab=xlabel)
  par(new=T)
  plot(time,fit[[1]],type="l",lwd=2,ylim=c(low,up),col="blue",ylab=ylabel,xlab=xlabel)
  par(new=T)
  plot(time,fit[[2]],type="l",lwd=2,ylim=c(low,up),col="black",ylab=ylabel,xlab=xlabel)
  par(new=T)
  abline(v=CI.break[1],lty=3,lwd=2)
  abline(v=CI.break[2],lty=3,lwd=2)
}

## ----------------------------------------------------------------------------------- ##
#########################################################################################
## ----------------------------------------------------------------------------------- ##
## Functions for nonparametric trend estimation (Section 4.1):                         ##                                  
## ----------------------------------------------------------------------------------- ##

## Regress data on a given number of Fourier terms and obtain residuals
remove.fourier <- function(y,time,terms){
  x.matrix <- matrix(data=0, nrow=length(time),ncol=2*terms+1)
  for (iter in 1:terms){
    x.matrix[,(2*(iter-1)+1)] <- cos(2*pi*iter*time)
    x.matrix[,(2*iter)] <- sin(2*pi*iter*time)
  }
  x.matrix[,(2*terms+1)] <- rep(1,length(time))
  fouriercoef <- solve(t(x.matrix) %*% x.matrix)%*%(t(x.matrix)%*%y)
  seasonal_adj <- y - x.matrix %*% fouriercoef
  return(seasonal_adj)
}

## Modified cross validation - bandwidth selection
MCV <- function(y,time,ell,grid,k){
  n <- length(y)
  dim <- length(grid)     
  CV <- rep(0, dim)
  for (i in 1:dim){
    m.hat.llo <- rep(0,n)
    for (j in (1+ell):(n-ell)){
      timeleaveout <- time
      timeleaveout[(j-ell):(j+ell)] <- 0
      yleaveout <- y
      yleaveout[(j-ell):(j+ell)] <- 0
      m.hat.llo[j] <- LCEstimation(yleaveout,timeleaveout,grid[i],k)[j]
    }
    errors <- y-m.hat.llo
    errors[1:ell] <- 0
    errors[(n-ell+1):n] <- 0
    CV[i] <- t(errors)%*%errors
  }
  ind <- which.min(CV)
  h.opt <- grid[ind]
  return(list(h.opt,CV))
}

## default: Local constant nonparametric estimator
LCEstimation <- function(y,time,h,k){
  diff <- outer(time,time,"-")/h
  k.diff <- do.call(k,list(diff))
  m.hat <- (k.diff %*% y)/rowSums(k.diff)
  return(m.hat)
}

## optional: Local linear nonparmetric estimator
LLEstimation <- function(y,time,h,k){
  n <- length(y) 
  m.hat <- rep(0,n)
  for (i in 1:n){
    diff <- (rep(time[i],n)-time)/h	
    ker <- do.call(k,list(diff))	                                                                                                        ## obtain estimate for every t=i/n
    zmatrix <- cbind(rep(1,n),rep(time[i],n)-time)
    bhat <- solve(t(zmatrix) %*% diag(ker) %*% zmatrix) %*% (t(zmatrix) %*% diag(ker) %*% y)
    m.hat[i] <-  bhat[1,]
  }
  return(m.hat)
}

## Autoregressive wild bootstrap
AWBootstrap <- function(y,time,m.tilde,B,h,newtime,k){
  n <- length(y)
  eps.hat <- y - m.tilde                                            
  m.hat.star <- matrix(data=0, nrow=n, ncol=B)
  for (b in 1:B){
    eps.star <- awb(eps.hat,time)
    y.star <- m.tilde + eps.star
    m.hat.star[,b] <- LCEstimation(y.star,newtime,h,k)
  }
  return(m.hat.star)	
}

## obtain pointwise confidence intervals
pointwise.int <- function(y,m.hat,m.star,m.tilde,alpha,B){
  n <- length(y)
  diff.beta <- m.star - matrix(data=m.tilde, nrow=n, ncol=B)
  beta.sorted <- matrix(data=NA, nrow=n, ncol=B)
  intervals.beta <- matrix(data=NA, nrow=n, ncol=2)
  for (i in 1:n){
    beta.sorted[i,] <- sort(matrix(data=diff.beta[i,], nrow=1, ncol=B), decreasing=FALSE)
    
  }                                                                                      ## construction of the intervals for the d different betas
  intervals.beta[,1] <- matrix(data=m.hat, nrow=n, ncol=1) - matrix(data=beta.sorted[,ceiling((1-(alpha/2))*B)], nrow=n, ncol=1)
  intervals.beta[,2] <- matrix(data=m.hat, nrow=n, ncol=1) - matrix(data=beta.sorted[,ceiling((alpha/2)*B)], nrow=n, ncol=1)
  return(intervals.beta)
}


## obtain simultaneous confidence bands over the set G
simult.int <- function(y,m.hat,m.tilde,m.star,alpha,B,G,G.total){
  n <- length(y)	
  
  diff.beta <- m.star - matrix(data=m.tilde, nrow=n, ncol=B)
  
  beta.sorted <- matrix(data=NA, nrow=n, ncol=B)
  intervals.beta <- matrix(data=NA, nrow=n, ncol=2)
  
  for (i in 1:n){		
    beta.sorted[i,] <- sort(matrix(data=diff.beta[i,], nrow=1, ncol=B), decreasing=FALSE)
  }
  
  alpha.p <- 1/B                                                                              ## starting value for pointwise error
  count.b <- 1
  beta.quantiles <- matrix(data=NA, nrow=n, ncol=2*ceiling(alpha*B)-2)     
  
  while (alpha.p < alpha){                                                                    ## compute pointwise quantiles for every candidate alpha.p in the interval [1/B, alpha]
    
    beta.quantiles[,count.b] <- beta.sorted[,ceiling((alpha.p/2)*B)]                      ## lower quantile
    beta.quantiles[,count.b+1] <- beta.sorted[,ceiling((1-alpha.p/2)*B)]                  ## upper quantile
    count.b <- count.b + 2
    alpha.p <- alpha.p + 1/B
  }
  
  beta.count <- 0
  beta.total <- 0
  alpha.p <- 1/B
  beta.ratio <- matrix(data=NA, nrow=ceiling(alpha*B)-1, ncol=1)
  x <- 1                                                               ## to go through the quantiles in steps of size 2
  xx <- 1                                                              ## to store the ratios for ever candidate alpha.p
  xb <- 1                                                              ## to go through the beta.quantiles in steps of size 2 
  while (alpha.p < alpha){                                             ## determine, for every candidate alpha.p, the ratio of bootstrap curves around y.hat/beta.hat that fall in the corresponding band
    
    for (j in 1:B){
      
      for (k in 1:G.total){           
        
        if ((diff.beta[G[k],j] <- beta.quantiles[G[k],xb+1]) && (diff.beta[G[k],j] >= beta.quantiles[G[k],xb])){
          beta.count <- beta.count + 1
        }   
      }
      
      if (beta.count == G.total){
        beta.total <- beta.total + 1
      }
      beta.count <- 0
    } 
    
    beta.ratio[xx] <- beta.total / B
    beta.total <- 0
    alpha.p <- alpha.p + 1/B
    x <- x + 2
    xx <- xx + 1
    xb <- xb + 2
  }
  
  beta.difference <- matrix(data=NA, nrow=ceiling(alpha*B)-1, ncol=1)                                                ## obtain values of the beta.ratios closest to 1-alpha and position at which this is attained
  beta.confidence <- matrix(data=NA, nrow=n, ncol=2)
  beta.difference <- beta.ratio - (1-alpha)
  beta.min <- which.min(abs(beta.difference))
  beta.confidence[,1] <- m.hat - beta.quantiles[,(2*beta.min)]
  beta.confidence[,2] <- m.hat - beta.quantiles[,(2*beta.min-1)]	
  return(beta.confidence)
}

## main function to run the nonparametric trend estimation
nonpara.trend <- function(y,time,B,alpha,h,k,terms=3,G=seq(1,length(y),1),C=0.5,l=5, grid=seq(0.01, by=0.005, length.out=50)){
  n <- length(y)
  newtime <- (time-time[1])/(time[n]-time[1])
  if (terms!=0){
    y <- remove.fourier(y,time,terms)
  }else if(terms<0){"invalid number of Fourier terms"}
  ## BANDWIDHT SELECTION
  if (h == -1){
    temp <- MCV(y,newtime,l,grid,k)
    h.opt <- temp[[1]]
    CV <- cbind(grid, temp[[2]])
  }else{
    h.opt <- h
  }
  h.tilde <- C*(h.opt)^(5/9)
  ## ESTIMATION AND CONFIDENCE INTERVALS 
  m.hat <- LCEstimation(y,newtime,h.opt,k)
  m.tilde <- LCEstimation(y,newtime,h.tilde,k)
  m.star <- AWBootstrap(y,time,m.tilde,B,h.opt,newtime,k)
  confidence.pw <- pointwise.int(y,m.hat,m.star,m.tilde,alpha,B)
  G.total <- length(G)
  confidence.simu <- simult.int(y,m.hat,m.tilde,m.star,alpha,B,G,G.total)
  if (h == -1){
    return(list(y,m.hat,confidence.pw,confidence.simu,h.opt,CV))
  }else{
    return(list(y,m.hat,confidence.pw,confidence.simu))
  }
}

## prints nonparametric trend estimate and CI, if desired
print.results.nonpara <- function(y,time,m.hat,int.s,low,up,xlabel,ylabel){
  plot(time, y, type="p", ylim=c(low,up), col="grey", xlab=xlabel, ylab=ylabel)
  par(new=T)
  plot(time, m.hat, type="l", lwd=1.5, ylim=c(low,up), col="black", xlab=xlabel, ylab=ylabel)
  par(new=T)
  plot(time, int.s[,1], type="l", lwd=1.5, ylim=c(low,up), col="blue", xlab=xlabel, ylab=ylabel)
  par(new=T)
  plot(time, int.s[,2], type="l", lwd=1.5, ylim=c(low,up), col="blue",  xlab=xlabel, ylab=ylabel)
}

## ----------------------------------------------------------------------------------- ##
#########################################################################################
## ----------------------------------------------------------------------------------- ##
## Functions for inference on trend shape (Section 4.2):                               ##                                         
## ----------------------------------------------------------------------------------- ##

max.loc <- function(y,start,end){
  location <- which.max(y[start:end])+(start-1)
  return(location)
}

min.loc <- function(y,start,end){
  location <- which.min(y[start:end])+(start-1)
  return(location)
}

## bootstrap for the extremum location
AWBootstrapMin <- function(y,time,m.tilde,B,alpha,h,newtime,k,min.max,ext){
  n <- length(y)
  eps.hat <- y - m.tilde                                            
  m.hat.star <- matrix(data=0, nrow=n, ncol=B)
  ext.ind <- rep(0,B)
  for (b in 1:B){
    eps.star <- awb(eps.hat,time)
    y.star <- m.tilde + eps.star			                                                       			         
    m.hat.star[,b] <- LCEstimation(y.star,newtime,h,k)
    if (ext=='max'){
      local.ext <- which(diff(sign(diff(m.hat.star[,b])))==-2)+1
    }else if(ext=='min'){
      local.ext <- which(diff(sign(diff(m.hat.star[,b])))==2)+1
    }else{"invalid extremum specification"}
    min.max2 <- which.min(abs(local.ext-min.max))
    ext.ind[b] <- local.ext[min.max2]
  }
  loc.sorted <- sort(ext.ind, decreasing=FALSE)
  CI.up <- loc.sorted[ceiling((1-(alpha/2))*B)]
  CI.low <- loc.sorted[ceiling((alpha/2)*B)]
  return(list(CI.low,CI.up))	
} 

## Analyzing an extremum location as in Section 4.2.1
ext.location <- function(y,time,h,alpha,B,m.hat,k,ext,start,end,C=0.5,terms=3){
  if (terms!=0){
    y <- remove.fourier(y,time,terms)
  }else if(terms<0){"invalid number of Fourier terms"}
  n <- length(y)
  newtime <- (time-time[1])/(time[n]-time[1])
  if (ext=='min'){
    min.max <- min.loc(m.hat,start,end)
  }else if(ext=='max'){
    min.max <- max.loc(m.hat,start,end)
  }else{"invalid extremum specification"}
  h.tilde <- C*(h)^(5/9)
  m.tilde <- LCEstimation(y,newtime,h.tilde,k)
  CI <- AWBootstrapMin(y,time,m.tilde,B,alpha,h,newtime,k,min.max,ext)
  return(list(min.max,c(CI[[1]],CI[[2]])))
}


## Bootstrap the test statistic Q_n from Section 4.2.2
shape.test.bootstrap <- function(beta,newtime,x.matrix,time,B,alpha,resid,h,k,start){
  n <- length(y)
  n.new <- n-start
  Q.ave.star <- rep(0,B)
  Q.sup.star <- rep(0,B)
  Q.exp.star <- rep(0,B)
  for (b in 1:B){
    eps.star <- awb(resid,time)		                                                                                
    y.star <- beta + eps.star
    m.star <- LCEstimation(y.star,newtime,h,k)
    y.star2 <- y.star - m.star[start]
    para.star <- solve(t(x.matrix) %*% x.matrix) %*% (t(x.matrix) %*% y.star2[(start+1):n])
    beta.star <- m.star[start] + c(para.star)*seq(1,n.new,1)
    Q.star <- (m.star[(start+1):n]-beta.star)^2
    Q.ave.star[b] <- mean(Q.star)
    Q.sup.star[b] <- max(Q.star)
    Q.exp.star[b] <- sum(exp(Q.star/2))/n.new
  }
  Q.ave.sorted <- sort(Q.ave.star, decreasing=FALSE)
  Q.sup.sorted <- sort(Q.sup.star, decreasing=FALSE)
  Q.exp.sorted <- sort(Q.exp.star, decreasing=FALSE)
  cv.ave <- Q.ave.sorted[ceiling((1-alpha)*B)]
  cv.sup <- Q.sup.sorted[ceiling((1-alpha)*B)]
  cv.exp <- Q.exp.sorted[ceiling((1-alpha)*B)]
  return(list(cbind(Q.ave.sorted,Q.sup.sorted,Q.exp.sorted),c(cv.ave,cv.sup,cv.exp)))
}

## Test for linearity/particular shape as in Section 4.2.2
run.shape.test <- function(y,time,h,alpha,B,m.hat,k,start, terms=3){
  n <- length(y)
  if (terms!=0){
    y <- remove.fourier(y,time,terms)
  }else if(terms<0){"invalid number of Fourier terms"}
  newtime <- (time-time[1])/(time[n]-time[1])
  n.new <- n-start
  ## force the 'new' trend to go through the last point of the nonparametric trend
  x.matrix <- seq(1,n.new,1)
  y.new <- y - m.hat[start]
  para <- solve(t(x.matrix) %*% x.matrix) %*% (t(x.matrix) %*% y.new[(start+1):n])
  trend <- m.hat[start] + c(para)%*%x.matrix
  Q_n <- (m.hat[(start+1):n]-trend)^2
  Q.ave <- mean(Q_n)
  Q.sup <- max(Q_n)
  Q.exp <- sum(exp(Q_n/2))/n.new
  beta <- c(m.hat[1:start],trend)
  eps.hat <- y-beta
  boot <- shape.test.bootstrap(beta,newtime,x.matrix,time,B,alpha,eps.hat,h,k,start)
  p.value.ave <- length(which(boot[[1]][,1] > Q.ave))/B
  p.value.sup <- length(which(boot[[1]][,2] > Q.sup))/B
  p.value.exp <- length(which(boot[[1]][,3] > Q.exp))/B
  return(list(c(Q.ave,Q.sup,Q.exp),boot[[2]],c(p.value.ave,p.value.sup,p.value.exp)))
}

## Obtain test statistics U1_n and U2_n from Section 4.2.3
mon.test.stat <- function(x,newtime,y,h,n){
  diff.matrix <- matrix(y, n, n, byrow=TRUE) - matrix(y, n, n, byrow=FALSE)
  ker.vec <- 0.75*(1-((newtime-x)/h)^2)
  ind <- I((newtime-x)/h>-1 & (newtime-x)/h<1)
  ker.vector <- ind*ker.vec
  ker.matrix <- ker.vector %*% t(ker.vector)
  test.matrix <- (-1)*sign(diff.matrix)*ker.matrix
  test.matrix[lower.tri(test.matrix,diag=TRUE)] <- 0
  test <- sum(sum(test.matrix))
  test.matrix2 <- (-1)*diff.matrix*ker.matrix
  test.matrix2[lower.tri(test.matrix2,diag=TRUE)] <- 0
  test2 <- sum(sum(test.matrix2))
  return(list(test*2/(h^2*n*(n-1)),test2*2/(h^2*n*(n-1))))
}

## bootstrap test statistics U1_n and U2_n from Section 4.2.3
mon.test.bootstrap <- function(trend,newtime,time,B,alpha,resid,h.test,k,start){
  n <- length(newtime)
  n.new <- n-start
  U1.sup.star <- rep(0,B)
  U2.sup.star <- rep(0,B)
  for (b in 1:B){
    eps.star <- awb(resid,time)		                                                                                
    y.star <- trend + eps.star
    U1.star <- rep(0,n.new)
    U2.star <- rep(0,n.new)
    for (i in 1:n.new){
      temp.star <- mon.test.stat(newtime[(i+start)],newtime,y.star,h.test,n)
      U1.star[i] <- temp.star[[1]]
      U2.star[i] <- temp.star[[2]]
    }
    U1.sup.star[b] <- max(U1.star)
    U2.sup.star[b] <- max(U2.star)
  }
  U1.sup.sort <- sort(U1.sup.star, decreasing=FALSE)
  cv.sup1 <- U1.sup.sort[ceiling((1-alpha)*B)]
  U2.sup.sort <- sort(U2.sup.star, decreasing=FALSE)
  cv.sup2 <- U2.sup.sort[ceiling((1-alpha)*B)]
  return(list(cbind(U1.sup.sort,U2.sup.sort),c(cv.sup1,cv.sup2)))
}

## Monotonicity tests from Section 4.2.3
run.mon.test <- function(y,time,h,alpha,B,m.hat,k,start,C=0.5,terms=3){
  n <- length(y)
  if (terms!=0){
    y <- remove.fourier(y,time,terms)
  }else if(terms<0){"invalid number of Fourier terms"}
  newtime <- (time-time[1])/(time[n]-time[1])
  n.new <- n-start
  h.test <- 0.5*n^(-1/5)
  U1_n <- rep(0,n.new)
  U2_n <- rep(0,n.new)
  for (i in 1:n.new){
    temp <- mon.test.stat(newtime[(i+start)],newtime,y,h.test,n)
    U1_n[i] <- temp[[1]]                                         
    U2_n[i] <- temp[[2]]
  }
  U1.sup <- max(U1_n)
  U2.sup <- max(U2_n)
  h.tilde <- C*(h)^(5/9)
  m.tilde <- LCEstimation(y,newtime,h.tilde,k)
  resid <- y - m.tilde
  boot <- mon.test.bootstrap(m.tilde,newtime,time,B,alpha,resid,h.test,k,start)
  p.value.sup1 <- length(which(boot[[1]][,1] > U1.sup))/B
  p.value.sup2 <- length(which(boot[[1]][,2] > U2.sup))/B
  return(list(c(U1.sup,U2.sup),boot[[2]],c(p.value.sup1,p.value.sup2)))
}