##########################################################################################
## ------------------------------------------------------------------------------------ ##
##                                                                                      ##
## This program contains R code with trend analysis tools as proposed in:               ##
##                                                                                      ##
##  Bader, W., Beutner, E., Franco, B., Friedrich, M., Lejeune, B., Mahieu, E.,         ##
##  Reuvers, H., Smeekes, S., Urbain, J.-P. (2019). Nonparametric estimation and        ##
##  bootstrap inference on trends in atmospheric time series: an application to ethane. ## 
##                                                                                      ##
## ------------------------------------------------------------------------------------ ##
##            Code by Marina Friedrich (friedrich@pik-potsdam.de)                       ##
## ------------------------------------------------------------------------------------ ##
##                                                                                      ##
## It contains four main functions to perform the following:                            ##
##   (1) Linear (broken) trend estimation (with confidence intervals). Sections 3.1-3.3 ##
##   (2) Nonparametric trend estimation with confidence intervals. Section 4.1          ##
##   (3) Confidence intervals around an extremum location. Section 4.2.1                ##
##   (4) Testing for a specific trend shape. Section 4.2.2                              ##
##   (5) Testing for monotonictiy of the trend function. Section 4.2.3                  ##
##                                                                                      ##
## Each function will be described in more details below.                               ##
## ------------------------------------------------------------------------------------ ##
##########################################################################################

# Call the functions in 'TrendAnalysisFunctions.R'
source("TrendAnalysisFunctions.R")

# Load your data, or use our Jungfraujoch ethane data as example
# Missing data should be deleted from both vectors,
# "time" should be in decimal format (e.g. 2011.8)
y <- scan("Jungfraujoch_conc.csv")
time <- scan("Jungfraujoch.csv")

##########################################################################################
## ------------------------------------------------------------------------------------ ##
##  FUNCTION (1)     lin.trend(y,time,B,alpha, terms=3, trim.frac=0.1)                  ##
## ------------------------------------------------------------------------------------ ##
##########################################################################################
## ------------------------------------------------------------------------------------ ##
##  Description of INPUT arguments:                                                     ##
## ------------------------------------------------------------------------------------ ##
##   y        Data vector of length n, containing the time series of interest           ##
##                                                                                      ##
##  time      A vector of length n, containing the corresponding dates in decimal       ##
##            format                                                                    ##
##                                                                                      ##
##   B        Number of bootstrap replication                                           ##
##                                                                                      ##
##  alpha     Nominal coverage of confidence intervals will be (1-alpha)                ##
##                                                                                      ##
##  terms     Number of Fourier terms, default equals 3                                 ##
##                                                                                      ##
## trim.frac  Parameter pi as described in Section 3.1, default equals 0.1              ##
## ------------------------------------------------------------------------------------ ##
##########################################################################################
## ------------------------------------------------------------------------------------ ##
##  Description of OUTPUT:                                                              ##
## ------------------------------------------------------------------------------------ ##
##   p.value          p-value of  the break test (Algorithm 2)                          ##
##                                                                                      ##
## critical.value     critical value of the break test (Algorithm 2)                    ##
##                                                                                      ##
##     S_T            test statistic S_T as in equation (3.5)                           ##
##                                                                                      ##
##     para           parameter estimates:                                              ##
##                    first: 6 coefficient estimates of Fourier terms (see eq. (3.3))   ##
##                    second: intercept, slope before break, slope after break          ##
##                                                                                      ##
##  fit.fourier       fitted values for the seasonal component F_T (equation (3.3))     ##
##                                                                                      ##
##   breakdate        location of the break                                             ##
##                                                                                      ##
##  CI.breakdate      confidence interval of break location                             ##
##                                                                                      ##
##    CI.para         confidence intervals for parameter estimates:                     ##
##                    presented in the same order as in "para" above                    ##
## ------------------------------------------------------------------------------------ ##
##########################################################################################

# Select arguments for the linear trend approach
alpha <- 0.05
B <- 999

# Apply the linear trend approach
lin.results <- lin.trend(y,time,B,alpha)

p.value <- lin.results[[1]]
critical.value <- lin.results[[2]]
S_T <- lin.results[[3]]
para <- lin.results[[4]]
fit.fourier <- lin.results[[5]]
breakdate <- lin.results[[6]]
CI.breakdate <- lin.results[[7]]
CI.para <- lin.results[[8]]

# Print output, using "low" and "up" for suitable y-axis bounds
low <- 0
up <- 5e+15
ylab <- "Ethane total column (molec cm-2)"
xlab <- ""
print.results.linear(y,time,fit.fourier,breakdate,CI.breakdate,low,up,xlab,ylab)

##########################################################################################
## ------------------------------------------------------------------------------------ ##
##  FUNCTION (2)     nonpara.trend(y,time,B,alpha,h,k, terms=3, G=seq(1,length(y),1),   ##
##                    C=0.5,l=5, grid=seq(0.01, by=0.005, length.out=50))               ##
## ------------------------------------------------------------------------------------ ##
##########################################################################################
## ------------------------------------------------------------------------------------ ##
##  Description of new(!) INPUT arguments:                                              ##
## ------------------------------------------------------------------------------------ ##
##                                                                                      ##
##   h        Bandwidth parameter for nonparametric estimation, can be selected by      ##
##            the user or by a data-driven selection method, called Modified Cross      ##
##            Validation (MCV) and will be started by selecting "h=-1" with parameter   ##
##            l=4 and a grid [0.001,0.099] by default. Both can be changed by the user  ##
##                                                                                      ##
##   k        kernel function for nonparametric estimation, see available kernels below ##
##                                                                                      ##
##   G        set of time indices over which the confidence bands will be made          ##
##            simultaneous, with default being whole sample                             ##
##                                                                                      ##
##   C        parameter determining the extend of oversmoothing in Step 1 of the        ##
##            bootstrap algorithm, default is 0.5                                       ##
##                                                                                      ##
##   l        parameter for MCV, default equals 4                                       ##
##                                                                                      ##
##  grid      range of possible bandwidth for MCV, default being [0.001,0.099] in steps ##
##            of 0.002                                                                  ##
##########################################################################################
## ------------------------------------------------------------------------------------ ##
##  Available KERNEL functions: Epanechnikov, Uniform, Quartic, Cosine                  ##                                                        ##
## ------------------------------------------------------------------------------------ ##
########################################################################################## 
## ------------------------------------------------------------------------------------ ##
##  Description of OUTPUT:                                                              ##
## ------------------------------------------------------------------------------------ ##
##     m.hat          a vector of length n containing the trend estimate                ##
##                                                                                      ##
## confidence.pw      a n by 2 matrix containing pointwise confidence intervals,        ##
##                    the lower bounds in column 1 and the upper bounds in column 2     ##
##                                                                                      ##
## confidence.simu    a n by 2 matrix containing simultaneous confidence bands,         ##
##                    the lower bounds in column 1 and the upper bounds in column 2     ##
##                                                                                      ##
##    h.opt           the bandwidth used to perform the estimation                      ##
##                                                                                      ##
##     CV             the MCV criterion, which we recommend to plot, especially if the  ##
##                    largest value is chosen. It often contains a local minimum        ##
##                    at a lower value, which should then be chosen by adjusting the    ##
##                    grid accordingly                                                  ##
## ------------------------------------------------------------------------------------ ##
########################################################################################## 

# Choose bandwidth or, if data driven bandwidth method (MCV) is desired, set h to -1
h <- -1

# Additional arguments for the approach
k <- k.epanech

# Estimation and confidence bands
nonpara.results <- nonpara.trend(y,time,B,alpha,h,k)
trend.est <- nonpara.results[[2]]
CI.pw <- nonpara.results[[3]]
CI.simu <- nonpara.results[[4]]
# Bandwidth used in case of selection by MCV, plots MCV criterion for visual inspection if desired
if (h == -1){
  h.opt <- nonpara.results[[5]]
  CV <- nonpara.results[[6]]
  plot(CV[,1], CV[,2], type = "l")
}

# Print output, using "low" and "up" for suitable y-axis bounds
low <- 1.1e+15
up <- 3e+15
ylab <- "Ethane total column - seas.adj. (molec cm-2)"
xlab <- ""
print.results.nonpara(nonpara.results[[1]],time,trend.est,CI.simu,low,up,xlab,ylab)

##########################################################################################
## ------------------------------------------------------------------------------------ ##
##  FUNCTION (3)     ext.location(y,time,h,alpha,B,m.hat,k,ext,start,end,C=0.5,terms=3) ##
## ------------------------------------------------------------------------------------ ##
##########################################################################################
## ------------------------------------------------------------------------------------ ##
##  Description of new(!) INPUT arguments:                                              ##
## ------------------------------------------------------------------------------------ ##
##                                                                                      ##
##   ext      type of extremum: minimum 'min' or maximum 'max'                          ##
##                                                                                      ##
##  start     beginning of the interval over which the program determines the extremum, ##
##            for the whole sample set equal to 1                                       ##
##                                                                                      ##
##   end      end point of the interval, for the whole sample set equal to length(y)    ##
##########################################################################################
## ------------------------------------------------------------------------------------ ##
##  Description of OUTPUT:                                                              ##
## ------------------------------------------------------------------------------------ ##
##    min.max         location of the extremum                                          ##
##                                                                                      ##
##     CI.ext         confidence interval for the extremum location                     ##
## ------------------------------------------------------------------------------------ ##
########################################################################################## 

# choose if you are interested in the maximum or minimum, select 'min' or 'max', and the
# beginning and end of the interval of interest (1 to length(y) for the whole sample) 
start <- 1
end <- length(y)
ext <- 'min'
ext.results <- ext.location(y,time,h.opt,alpha,B,trend.est,k,ext,start,end)
min.max <- ext.results[[1]]
CI.ext <- ext.results[[2]]

##########################################################################################
## ------------------------------------------------------------------------------------ ##
##  FUNCTION (4)     run.shape.test(y,time,h,alpha,B,m.hat,k,start, terms=3)            ##
## ------------------------------------------------------------------------------------ ##
##########################################################################################
## ------------------------------------------------------------------------------------ ##
##  Description of OUTPUT:                                                              ##
## ------------------------------------------------------------------------------------ ##
##    Q.summary       vector containing the test statistics Q.sup, Q.ave, Q.exp         ##
##                                                                                      ##
##   cv.Summary       vector of critical values for the three test statistics           ##
##                                                                                      ##
##    p.summary       vector containing the p-values for Q.sup, Q.ave, Q.exp            ##
## ------------------------------------------------------------------------------------ ##
##########################################################################################

# select where the linear or quadratic trend should start
start <- min.max

trend.shape <- run.shape.test(y,time,h.opt,alpha,B,trend.est,k,start)
Q.summary <- trend.shape[[1]]
cv.summary <- trend.shape[[2]]
p.summary <- trend.shape[[3]]

##########################################################################################
## ------------------------------------------------------------------------------------ ##
##  FUNCTION (5)     run.mon.test(y,time,h,alpha,B,m.hat,k,start, C=0.5, terms=3)       ##
## ------------------------------------------------------------------------------------ ##
##########################################################################################
## ------------------------------------------------------------------------------------ ##
##  Description of OUTPUT:                                                              ##
## ------------------------------------------------------------------------------------ ##
##    U.test       vector containing the test statistics U1.sup and U2.sup              ##
##                                                                                      ##
##    U.cv         vector of critical values for the two test statistics                ##
##                                                                                      ##
##    U.p          vector containing the p-values for U1.sup and U2.sup                 ##
## ------------------------------------------------------------------------------------ ##
##########################################################################################

mon.test.results <- run.mon.test(y,time,h.opt,alpha,B,trend.est,k,start)
U.test <- mon.test.results[[1]]
U.cv <- mon.test.results[[2]]
U.p <- mon.test.results[[3]]
