# OLS
ols <- function(y,x) {
	y <- as.matrix(y)
	x <- as.matrix(x)
	b <- solve(crossprod(x),crossprod(x,y))
	return(b)
}

# Matrix of lags
lgm <- function(y, p, trim = TRUE) {
	x <- as.matrix(y)
	n <- nrow(x)
	k <- ncol(x)
	lx <- matrix(0, nrow = n, ncol = length(p)*k)
	for (i in 1:length(p)) {
		lx[(1+p[i]):n, k*(i-1) + 1:k] <- x[1:(n-p[i]),]
	}
	return(lx[(1 + trim*max(p)):n, , drop = FALSE])
}

# (Quasi) Differences
dif <- function(y, c = 1, trim = TRUE) {
	x <- as.matrix(y)
	ly <- as.matrix(lgm(y, 1, trim = FALSE))
	dy <- (x - c*ly)[(1 + trim):nrow(x),]
	return(dy)
}

# Order statistics of a vector
order.stat <- function(x, k) {sort(x, partial = k)[k]}

# Modified function for AR series as a shell for "filter" to work on arrays
filter.array <- function(x, rho, init = NULL) {
	x <- matrix(x, nrow = dim(x)[1])
	rho <- matrix(rho, ncol = ncol(x))
	if (is.null(init)) {
		init = x[nrow(rho):1, , drop = FALSE]
	} else {
		init = as.matrix(init, ncol = ncol(x))
	}
	y <- sapply(1:ncol(x), function(i){filter(x[, i], rho[, i], method = "r", init = init[, i])}, simplify = "array")
	return(y)
}

# Detrending of (possibly multivariate) time series
detrend <- function(y, dc, QD = FALSE, c.QD = c(7, 13.5)) {
	n <- NROW(y)
	if (dc > 0) {
		p <- floor(dc/2)
		d <- outer(1:n, 0:p, "^")
		c.n <- QD * (1 -  c.QD[dc] / n)
		d.QD <- dif(d, c = c.n, trim = FALSE)
		y.QD <- dif(y, c = c.n, trim = FALSE)
		b.trend <- ols(y.QD, d.QD)
		x <- y - d %*% b.trend
	} else {
		x <- as.matrix(y)
	}
	return(x)
}

# ADF test statistics (coefficient and t-test) on a single time series
adf <- function(z, p, dc = 1, QD = FALSE, trim = TRUE, trim.ic = 0) {
	n <- length(z)
	y <- detrend(z, dc = dc, QD = QD)
	y.lag <- lgm(y, 1, FALSE)
	y.dif <- y - y.lag
	p.max <- max(p)
	if (p.max > 0) {
		y.dif.lags <- lgm(y.dif, p[p>0], trim = FALSE)
		x <- cbind(y.lag, y.dif.lags)
	} else {
		x <- y.lag
	}
	trim.t <- 1 + (1 + (trim.ic == 0) * p.max + trim.ic) * trim
	x <- x[trim.t:n,]
	b <- ols(y.dif[trim.t:n], x)
	e <- y.dif[trim.t:n] - x%*%b
	s.2 <- crossprod(e)/(n - trim.t + 1)
	t.adf <- b[1] / sqrt(s.2 * solve(crossprod(x))[1,1])
	c.adf <- n*b[1] / (1 - sum(b[-1]))
	return(list(t.ADF = t.adf, c.ADF = c.adf, par = b, res = e))
}

# Akaike Information Criterion
AIC <- function(e, k, n, b.0 = 0, y.lag = 0) {
	s.2 <- crossprod(e) / n
	return(log(s.2) + k * 2 / n)
}

# Bayesian Information Criterion
BIC <- function(e, k, n, b.0 = 0, y.lag = 0) {
	s.2 <- mean(e^2)
	return(log(s.2) + k * log(n) / n)
}

# Modified Akaike Information Criterion
MAIC <- function(e, k, n, b.0 = 0, y.lag = 0) {
	s.2 <- crossprod(e) / n
	t.k <- crossprod(y.lag) * b.0^2 / s.2
	return(log(s.2) + (k + t.k) * 2 / n)
}

# Modified Bayesian Information Criterion
MBIC <- function(e, k, n, b.0 = 0, y.lag = 0) {
	s.2 <- crossprod(e) / n
	t.k <- crossprod(y.lag) * b.0^2 / s.2
	return(log(s.2) + (k + t.k) * log(n) / n)
}

# ADF with lag length selection
adf.selectlags <- function(y, p.min = 0, p.max = round(12 * (length(y)/100)^(1/4) ), ic = "MAIC", dc = 1, QD = FALSE, trim = TRUE) {
	n <- length(y)
	y.lag <- detrend(y, dc, QD = FALSE)[-c(1:p.max, n)]
	ic.a <- sapply(p.min:p.max, function(p){
		adf.p <- adf(y, 0:p, dc, QD = FALSE, trim = trim, trim.ic = p.max)
		do.call(ic, list(e = adf.p$res, k = p, n = n - p.max - 1, b.0 = adf.p$par[1], y.lag = y.lag))
	})
	p.opt <- which.min(ic.a) + p.min - 1
	ADF.p <- adf(y, 0:p.opt, dc, QD, trim = trim)
	return(list(t.ADF = ADF.p$t.ADF, c.ADF = ADF.p$c.ADF, par = ADF.p$par, res = ADF.p$res, p = p.opt, ic = ic.a))
}

# Collect different ADF tests (for the union test)
adf.tests <- function(y, p.min = 0, p.max = round(12 * (length(y)/100)^(1/4) ), ic = "MAIC", dc = 1, type = "OLS") {
	if ("OLS" %in% type) {
		ols.tests <- sapply(dc, function(i) {
			adf.dc <- adf.selectlags(y, p.min = p.min, p.max = p.max, ic = ic, dc = i, QD = FALSE)
			return(c(adf.dc$t.ADF, adf.dc$p))
		})
		if ("QD" %in% type) {
			p.ols <- ols.tests[2,]
			qd.tests <- sapply(1:length(dc), function(i) {
				adf.dc <- adf(y, p = 0:p.ols[i], dc = dc[i], QD = TRUE)
				return(adf.dc$t.ADF)
			})
			tests <- c(ols.tests[1,], qd.tests)
		} else {
			tests <- ols.tests[1,]
		}
	} else if ("QD" %in% type) {
		tests <- sapply(1:length(dc), function(i) {
			adf.dc <- adf.selectlags(y, p.min = p.min, p.max = p.max, ic = ic, dc = i, QD = TRUE)
			return(adf.dc$t.ADF)
		})
	}
	names(tests) <- t(outer(type, dc, paste))
	return(tests)
}

# ADF tests over the whole panel
adf.panel <- function(y, p.min = 0, p.max = round(12 * (NROW(y)/100)^(1/4) ), ic = "MAIC", dc = 1, QD = FALSE, trim = TRUE) {
	y <- as.matrix(y)
	T <- nrow(y)
	N <- ncol(y)
	tests <- matrix(nrow = 2, ncol = N)
	rownames(tests) <- c("t.ADF", "c.ADF")
	e <- matrix(nrow = T, ncol = N)
	par <- matrix(nrow = 1 + p.max - p.min, ncol = N)
	p <- rep(NA, N)
	for (i in 1:N){
		adf.i <- adf.selectlags(y[,i], p.min = p.min, p.max = p.max, ic = ic, dc = dc, QD = QD, trim = trim)
		tests[, i] <- c(adf.i$t.ADF, adf.i$c.ADF)
		p[i] <- adf.i$p
		e[(trim*(p[i] + 1) + 1):T, i] <- adf.i$res
		par[1:(p[i] + 1), i] <- adf.i$par
	}
	return(list(tests = tests, res = e, par = par, p = p))
}

# Collect all individual test statistics
tests.all.units <- function(y, p.min = 0, p.max = round(12 * (NROW(y)/100)^(1/4) ), ic = "MAIC", dc = 1, type = "OLS"){
	tests <- apply(y, 2, adf.tests, p.min = p.min, p.max = p.max, ic = ic, dc = dc, type = type)
	return(tests)
}

dgp <- function(t, n, ar = 0, ma = 0) {
	e <- matrix(rnorm(n*(t+1)), nrow = t + 1)
	u <- filter.array(e[1:t + 1,] + ma * e[1:t,], rep(ar, n))
	y <- filter.array(u, rep(1, n))
}

# Moving Block Bootstrap series
MBB <- function(u, l, y.0 = rep(0, NCOL(u))) {
	u <- as.matrix(u)
	T <- nrow(u)
	N <- ncol(u)
	nb <- ceiling(T/l)
	start.b <- sample.int(T - l + 1, size = nb, replace = TRUE) - 1
	u.star <- matrix(nrow = nb*l + 1, ncol = N)
	u.star[1, ] <- y.0
	for (i in 1:nb) {
		u.star[1:l + (i-1)*l + 1,] <- u[1:l + start.b[i], ]
	}
	y.star <- apply(u.star[0:T + 1,], 2, cumsum)
	return(y.star)
}

# Panel bootstrap tests
bootstrap.tests <- function(i, u, l, y.0 = rep(0, NCOL(u)), p.min = 0, p.max = round(12 * ((NROW(u)+1)/100)^(1/4) ), ic = "MAIC", dc = 1, type = "OLS") {
	y.star <- MBB(u = u, l = l, y.0 = y.0)
	tests.star <- tests.all.units(y.star, p.min = p.min, p.max = p.max, ic = ic, dc = dc, type = type)
	return(tests.star)
}

# Parallel bootstrap procedure
bootstrap <- function(B, u, l, y.0 = rep(0, NCOL(u)), p.min = 0, p.max = round(12 * ((NROW(u)+1)/100)^(1/4) ), ic = "MAIC", dc = 1, type = "OLS", parallel = FALSE, cl = NULL) {
	if (parallel) {
		tests.star <- parSapply(cl, 1:B, bootstrap.tests, u = u, l = l, y.0 = y.0, p.min = p.min, p.max = p.max, ic = ic, dc = dc, type = type, simplify = "array")
	} else {
		tests.star <- sapply(1:B, bootstrap.tests, u = u, l = l, y.0 = y.0, p.min = p.min, p.max = p.max, ic = ic, dc = dc, type = type, simplify = "array")
	}
	t.star <- aperm(array(tests.star, dim = c(length(dc)*length(type), NCOL(u), B)), c(3,1,2))
	dimnames(t.star) <- list(paste("b", 1:B, sep = ""), dimnames(tests.star)[[1]], paste("i", 1:NCOL(u), sep = ""))
	return(t.star)
}

# Scaling factors union tests
scaling.factors <- function(t.star, a = 0.05) {
#	sc.f <- apply(t.star, c(2,3), sort)		# all levels
	sc.f <- apply(t.star, c(2,3), quantile, probs = a)
	return(sc.f)
}

# Union tests
union.tests <- function(t, c, x = rep(-1, dim(t)[2])) {
	if (dim(t)[2] > 1) {
		u.tests <- apply(t, 1, function(t){apply(t / c, 2, function(s){min(s*x)})})
	} else {
		u.tests <- t
	}
	return(u.tests)
}

# Single step in the sequential testing procedure
BSQT.step <- function(p.0, p.1, theta.i, ranks, t.star) {
	if (p.0 > 0) {
		t.star.sub <- t.star[-ranks[1:p.0], , drop = FALSE]
	} else {
		t.star.sub <- t.star
	}
	theta.j <- theta.i[ranks[p.1]]
	theta.star <- apply(t.star.sub, 2, order.stat, k = p.1 - p.0)
	p.val.j <- mean(theta.star < theta.j)
	return(c(q.H0 = round(p.0/NROW(theta.i), digits = 3), p.H0 = p.0, q.H1 = round(p.1/NROW(theta.i), digits = 3), p.H1 = p.1, unit.p.H1 = ranks[p.1], theta = theta.j, p.val = p.val.j))
}

# Sequential Testing algorithm (tau.SQ)
BSQT.alg <- function(p.vec, theta.i, t.star, a = 0.05, parallel = FALSE, cl = NULL) {
	N <- NROW(theta.i)
	ranks <- order(theta.i)
	if (p.vec[1] > 0) {
		p.vec <- c(0,p.vec);
	}
	if (p.vec[length(p.vec)] < N) {
		p.vec <- c(p.vec,N);
	}
	K <- length(p.vec) - 1
	if (parallel){
		step.stats <- parSapply(cl, 1:K, function(j){BSQT.step(p.0 = p.vec[j], p.1 = p.vec[j+1], theta.i, ranks, t.star)}, simplify = "array")
	} else {
		step.stats <- sapply(1:K, function(j){BSQT.step(p.0 = p.vec[j], p.1 = p.vec[j+1], theta.i, ranks, t.star)}, simplify = "array")
	}
	p.hat <- p.vec[step.stats[7,] > a][1]
	if (p.hat>0) {
		S.x <- (1:N)[ranks[1:p.hat]]
	} else {
		S.x <- NULL
	}
	return(list(p.hat = p.hat, S.x = S.x, Steps.Details = t(step.stats)))
}

# Bootstrap Sequential Quantile Tests (main function)
BSQT <- function(y, level = 0.05, q = 0:NCOL(y), B = 9999, union = TRUE, p.min = 0, p.max = round(12 * (NROW(y)/100)^(1/4) ), ic = "MAIC", dc = 1, type = "OLS", l = round(1.75*NROW(y)^(1/3)), parallel = FALSE, nr.cores = NULL) {
	start.time <- proc.time()
	y <- as.matrix(y)
	T <- NROW(y)
	N <- NCOL(y)
	if (is.numeric(q) && all(q == floor(q) & q >= 0)) {
		p.vec <- sort(unique(q))
	} else if (is.numeric(q) && all(q >= 0 & q <= 1)) {
		p.vec <- sort(unique(round(q*N)))
	} else {
		stop("Invalid input values for q: must be quantiles or positive integers")
	}

	if (union) {
		dc <- c(1,2)
		type <- c("OLS", "QD")
	}
	panel.est <- adf.panel(y, p.min = 0, p.max = 0, dc = 2, QD = FALSE)
	u.boot <- na.omit(panel.est$res)

	if (parallel){
		library(parallel)
		if (is.null(nr.cores)) {nr.cores <- detectCores() - 1}
		cl <- makeCluster(nr.cores)
		clusterSetRNGStream(cl, sample.int(2^20, size = 1))
		clusterExport(cl = cl, Filter(function(x) is.function(get(x, .GlobalEnv)), ls(.GlobalEnv)))		# Export all defined functions to all the cores - cores don't know them otherwise
	}

	t.star.s <- bootstrap(B = B, u = u.boot, l = l, y.0 = y[1,], p.min = p.min, p.max = p.max, ic = ic, dc = dc, type = type, parallel = parallel, cl = cl)
	scaling <- scaling.factors(t.star.s, a = level)
#	t.star <- bootstrap(B = B, u = u.boot, l = l, y.0 = y[1,], p.min = p.min, p.max = p.max, ic = ic, dc = dc, type = type, parallel = parallel, cl = cl)
	t.star <- t.star.s
	theta.star <- union.tests(t.star, scaling)
	tests.i <- tests.all.units(y, p.min = p.min, p.max = p.max, ic = ic, dc = dc, type = type)
	theta.i <- union.tests(array(tests.i, dim = c(1, length(dc) * length(type), N)), scaling)
	BSQT.out <- BSQT.alg(p.vec = p.vec, theta.i = theta.i, t.star = theta.star, a = level, parallel = parallel, cl = cl)
#print(theta.i)
	if (parallel) {
		stopCluster(cl)
	}
	Step.Details <- BSQT.out$Steps.Details
	if (!is.null(colnames(y))) {
		BSQT.out$S.x <- colnames(y)[BSQT.out$S.x]
		Step.Details <- data.frame(BSQT.out$Steps.Details[, 1:4], unit.p.H1 = colnames(y)[BSQT.out$Steps.Details[, 5]], BSQT.out$Steps.Details[, 6:7] )#stringsAsFactors = FALSE)
	} else {
		Step.Details <- data.frame(BSQT.out$Steps.Details)#stringsAsFactors = FALSE)
	}
	return(list(p.hat = BSQT.out$p.hat, S.x = BSQT.out$S.x, Step.Details = Step.Details, running.time = proc.time() - start.time))
}
