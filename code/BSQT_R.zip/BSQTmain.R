##################################################################################
#                                                                                #
# R code to perform bootstrap sequential tests proposed in                       #
#                                                                                #
# Smeekes, S. (2015). Bootstrap sequential tests to determine the order of       #
#    integration of individual units in a time series panel. Journal of Time     #
#    Series Analysis 36, 398-415.                                                #
#                                                                                #
# Code by Stephan Smeekes (e-mail: S.Smeekes@maastrichtuniversity.nl)            #
#                                                                                #
# A description of the main function "BSQT" can be found below.                  #
#                                                                                #
##################################################################################

##################################################################################
#### function: BSQT ##############################################################
##################################################################################
#### Description #################################################################
##################################################################################
#                                                                                #
# Performs bootstrap sequential tests for determining I(0) / I(1) time series in #
# a panel, as described in the paper                                             #
#                                                                                #
# Smeekes, S. (2015). Bootstrap sequential tests to determine the order of       #
#    integration of individual units in a time series panel. Journal of Time     #
#    Series Analysis 36, 398-415.                                                #
#                                                                                #
##################################################################################
#### Usage #######################################################################
##################################################################################
#                                                                                #
# BSQT(y, level = 0.05, q = 0:NCOL(y), B = 9999, union = TRUE, dc = 1,           #
#     type = "OLS", l = round(1.75*NROW(y)^(1/3)), p.min = 0,                    #
#     p.max = round(12 * (NROW(y)/100)^(1/4) ), ic = "MAIC", parallel = FALSE,   #
#     nr.cores = NULL)                                                           #
#                                                                                #
##################################################################################
#### Arguments ###################################################################
##################################################################################
#                                                                                #
# y         Data matrix of dimensions T times N containing the time series to be #
#           tested for unit roots.                                               #
# level     Significance level of the sequential test. Default is 0.05.          #
# q         The vector of consecutive units or quantiles to be tested            #
#           sequentially. Values can be given both in quantiles or units.        #
#           If the vector does not start with 0 (which is the first null         #
#           hypothesis, or ends with N (quantile 1) (the final alternative       #
#           hypothesis), these will be added automatically. The defaults is the  #
#           vector 0,1,2,...,N, which amounts to testing unit-by-unit.           #
# B         Number of bootstrap replications. Default is 9999.                   #
# union     Specifies whether the ADF union tests of Smeekes and Taylor (2012)   #
#           should be used. Default is TRUE.                                     #
# dc        Deterministic specification (in case of no union test): no           #
#           deterministic components (0), data are demeaned (1), or data are     #
#           detrended (2). Default is 1.                                         #
#           Type of detrending used (in case of no union test): OLS or QD (GLS)  #
#           detrending. Default is OLS.                                          #
# l         Block length used for the moving-block bootstrap. The default is     #
#           [1.75*T^(1/3))].                                                     #
# p.min     Minimum lag length in the ADF test for the information criterion.    #
#           Default is 0.                                                        #
# p.max     Maximum lag length in the ADF test for the information criterion.    #
#           Default is [12 (T / 100)^(1/4))].                                    #
# ic        Information criterion to be used. Default is MAIC.                   #
# parallel  If TRUE, parallel computing from the package 'parallel' (part of the #
#           standard R distribution) is implemented using its 'parLapply'        #
#           functionality (available on all platforms including Windows). The    #
#           default is FALSE, such that no parallel computing is used.           #
# nr.cores  Specifies the number of cores used for parallel computing. Default   #
#           is NULL, in which case R uses all available cores minus one.         #
#                                                                                #
##################################################################################
#### Value #######################################################################
##################################################################################
#                                                                                #
# A list with elements                                                           #
#                                                                                #
# p.hat         The number of predictable units                                  #
# S.x           The set of predictable units                                     #
# Steps.Details A data frame of dimensions K x 7, where K is the number of       #
#               sequential tests performed. Each row contains the number of      #
#               predictable units and quantile under the null (p.H0, q.H0) and   #
#               under the alternative (p.H1, q.H1), the unit corresponding to    #
#               the order statistic used in that step (unit.p.H1), the test      #
#               statistic (theta) and the bootstrap p-value (p.val).             #
#                                                                                #
# running.time  The running time of the function. Its output is identical to the #
#               output of system.time().                                         #
#                                                                                #
##################################################################################

# Call the functions in 'BSQTfunctions.R'.
source("BSQTfunctions.R")

# Load data: replace the simulated "y" with data of interest.
T <- 100; N <- 10; yy <- matrix(rnorm(T*N), nrow = T);

y <- read.csv("DataPSID.csv")[, -1]

# Perform the test(s).
BSQT.out <- BSQT(y, parallel = TRUE, B = 9999, p.min = 0, p.max = 3, q = 0:5/6) 
