##################################################################################
#                                                                                #
# R code to perform modified wild bootstrap panel unit root tests proposed in    #
#                                                                                #
# Smeekes, S. and J.-P. Urbain (2014). A Multivariate Invariance Principle for   #
#   Modified Wild Bootstrap Methods with an Application to Unit Root Testing.    #
#   GSBE Research Memorandum RM/14/008, Maastricht University.                   #
#                                                                                #
# Code by Stephan Smeekes (e-mail: S.Smeekes@maastrichtuniversity.nl)            #
#                                                                                #
# A description of the main function "mwbpur" can be found below                 #
#                                                                                #
##################################################################################

##################################################################################
#### function: mwbpur ############################################################
##################################################################################
#### Modified Wild Bootstrap Panel Unit Root Tests ###############################
##################################################################################
#### Description #################################################################
##################################################################################
#                                                                                #
# mwbpur performs modified wild bootstrap panel unit root tests as described in  #
#                                                                                #
# Smeekes, S. and J.-P. Urbain (2014). A Multivariate Invariance Principle for   #
#   Modified Wild Bootstrap Methods with an Application to Unit Root Testing.    #
#   GSBE Research Memorandum RM/14/008, Maastricht University.                   #
#                                                                                #
##################################################################################
#### Usage #######################################################################
##################################################################################
#                                                                                #
# mwbpur(y, test, bs, B, lvl, kappa, gls.dt, adf.coef, l.bwb = -1, l.dwb = -1,   #
#     k.dwb = kTBB, gamma.awb = -1, p.fixed = -1, p.max = -1, ic = maic,         #
#     ls.boot = 1, rs = 1, k.rs = gaussian, h.rs = 0.1, c.gls = c(7, 13.5),      #
#     out.scr = 1)                                                               #
#                                                                                #
##################################################################################
#### Arguments ###################################################################
##################################################################################
#                                                                                #
# y         Data matrix of dimensions T times N. For unbalanced panels, T        #
#           should be equal to the total number of time periods in the panel.    #
#           Missing values should be entered in the matrix as NA.                #
# test      Panel test statistic to use (mean and median are options).           #
# bs        Bootstrap method(s) to use.                                          #
# B         Number of bootstrap replications.                                    #
# lvl       Significance level.                                                  #
# kappa     Deterministic specification: no deterministic components (-1),       #
#           constant only (0), or constant and trend (1).                        #
# gls.dt    Set TRUE for GLS detrending, and FALSE for OLS detrending. In case   #
#           of GLS information criteria are still applied to OLS detrended data, #
#           see e.g. Perron and Qu (2007).                                       #
# adf.coef  Set TRUE for ADF coefficient test or FALSE for ADF t-test.           #
# l.bwb     Tuning parameter (block length) for BWB; set -1 for sample size-     #
#           dependent rule [1.75*T^(1/3))]. Default is -1.                       #
# l.dwb     Tuning parameter for DWB; set -1 for sample size-dependent rule      #
#           [1.75*T^(1/3))]. Default is -1.                                      #
# k.dwb     Kernel for the DWB. Default is kTBB (see Shao, 2010, Remark 2.1 or   #
#           the functions above)                                                 #
# gamma.awb Tuning parameter (gamma) for AWB; set -1 for sample-size dependent   #
#           rule 0.01^[1.75*T^(1/3))]. Default is -1.                            #
# p.min     Minimum lag length for the ADF for use in an information criterion.  #
#           Set equal to p.max for a fixed lag length. Default is 0.             #
# p.max     Maximum lag length of the ADF for use in an information criterion.   #
#           Set -1 to use sample size-dependent rule [12*(T/100)^(1/4)].         #
#           Default is -1.                                                       #
# ic        Information criterion for lag selection ADF. Available are AIC, BIC, #
#           MAIC and MBIC. Default is MAIC.                                      #
# ls.boot   Set TRUE for lag selection inside the bootstrap. If set to FALSE,    #
#           the original ADF lag length is used within the bootstrap. Default is #
#           TRUE.                                                                #
# rs        Set TRUE to use heteroskedasticity-robust rescaled (RS) information  #
#           criteria (see Cavaliere et al., 2012) or FALSE for the original      #
#           versions. Default is TRUE.                                           #
# k.rs      Kernel to be used in nonparametric variance estimation for rescaled  # 
#           information criteria. Default is gaussian.                           #
# h.rs      Bandwidth to be used in nonparametric variance estimation for        # 
#           rescaled information criteria. Default is 0.1.                       #
# out.scr   Set TRUE for a summary of the test output on the console screen, or  #
#           FALSE for no output. Default is TRUE.                                #
#                                                                                #
##################################################################################
#### Value #######################################################################
##################################################################################
#                                                                                #
# mwbpur returns a list containing the following components:                     #
#                                                                                #
# test.statistics   A named vector of test statistics                            #
# critical.values   A named matrix of critical values (for the pre-specified     #
#                   significance level) with entries for each test and bootstrap #
#                   method used                                                  #
# p.values          A named matrix of p-values with entries for each test and    #
#                   bootstrap method used                                        #
# lag.lengths       A vector with lag lengths for each cross-sectional unit      #
#                   cross-sectional unit and each bootstrap replication          #
# running.time      Running time of the function. Output is identical to output  #
#                   of system.time().                                            #
#                                                                                #
##################################################################################
#### Notes #######################################################################
##################################################################################
#                                                                                #
# Available kernels: bartlett, gaussian, kTBB, parzen, quadratic.spectral,       #
#                    truncated, tukey.hanning.                                   #
#                                                                                #
##################################################################################

# Call the functions in 'MWBfunctions.R'.
source("MWBfunctions.R");

# Load data: replace the simulated "y" with data of interest.
T <- 100; N <- 10; y <- filter(array(rnorm(T*N),c(T,N)),1,"r");

# Required arguments for mwbpur.
test <- c("mean","median");
bs <- c("BWB","DWB","AWB");
B <- 999;
lvl <- 0.05;
kappa <- 0;
gls.dt <- FALSE;
adf.coef <- FALSE;

# Perform the test(s).
outp <- mwbpur(y,test,bs,B,lvl,kappa,gls.dt,adf.coef);

