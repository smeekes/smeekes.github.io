##################################################################################
#                                                                                #
#  R code to perform modified wild bootstrap panel unit root tests proposed in   #
#                                                                                #
#  Smeekes, S. and J.-P. Urbain (2014). A Multivariate Invariance Principle for  #
#    Modified Wild Bootstrap Methods with an Application to Unit Root Testing.   #
#    GSBE Research Memorandum RM/14/008, Maastricht University.                  #
#                                                                                #
#  Code by Stephan Smeekes (e-mail: S.Smeekes@maastrichtuniversity.nl)           #
#                                                                                #
#  This file contains the functions needed to perform the tests. Call this file  #
#  in 'MWBmain.R' for execution of the code.                                     #
#                                                                                #
##################################################################################

# String containing elapsed time
etstr <- function(et) {
  dhms.sec <- c(60*60*24,60*60,60);
  dhms.str <- c("day", "hour", "minute")
  ets <- "Elapsed time:";
  etsi <- "";
  etr <- et[3];
  for (i in 1:3) {
    et.dhms <- etr%/%dhms.sec[i];
    etr <- etr%%dhms.sec[i];
	if (et.dhms > 1) {
	  dhms.str[i] <- paste(dhms.str[i],"s",sep="");
	}
	if (et.dhms > 0) {
	  if (i < 3) {
	    dhms.str[i] <- paste(dhms.str[i],",",sep="");		
	  } else {
	  	dhms.str[i] <- paste(dhms.str[i],"and",sep=" ");
	  }
	  etsi <- paste(etsi,et.dhms,dhms.str[i]);
	}
  }
  etsi <- paste(etsi,round(etr,2),"seconds.");
  ets <- paste(ets,etsi,sep="");
  return(ets);
}

# Presents summary output on console screen
MWB.output <- function(outp,test,bs,B,lvl,kappa,gls.dt,adf.coef) {
  n <- 60
	cat(paste(rep("-",n),sep="",collapse=""),fill=TRUE);
	cat(paste(rep("-",n),sep="",collapse=""),fill=TRUE);
	cat("Results from MWB panel unit root tests.",fill=TRUE);
	cat(paste("Significance level:",lvl,"/ Bootstrap replications:",B),fill=TRUE);
	if (identical(kappa,-1)) {
		tspec <- "No deterministic components /";
	} else if (identical(kappa,0)) {
		tspec <- "Intercept only /";
	} else if (identical(kappa,1)) {
		tspec <- "Intercept and trend /";
	}
	if ((gls.dt)&&(kappa>=0)) {
		tspec <- paste(tspec,"GLS detrending /");
	} else if ((gls.dt==FALSE)&&(kappa>=0)) {
		tspec <- paste(tspec,"OLS detrending /");
	}
	if (adf.coef) {
		tspec <- paste(tspec,"ADF coefficient-test.");
	} else {
		tspec <- paste(tspec,"ADF t-test.");
	}
	cat(tspec,fill=TRUE);
	cat(paste(rep("-",n),sep="",collapse=""),fill=TRUE);
	print(lapply(outp[1:3],format,digits=3),quote=FALSE);
	cat(paste(rep("-",n),sep="",collapse=""),fill=TRUE);
	cat(paste("Average ADF lag length:",signif(mean(outp$lag.lengths),3)),fill=TRUE);
	cat(paste(rep("-",n),sep="",collapse=""),fill=TRUE);
	cat(etstr(outp$running.time),fill=TRUE);
	cat(paste(rep("-",n),sep="",collapse=""),fill=TRUE);
	cat(paste(rep("-",n),sep="",collapse=""),fill=TRUE);
}

# OLS coefficient vector
ols <- function(y,x) {
  b <- solve(crossprod(x),crossprod(x,y));
  return(b);
}

# Matrix of lags (up to order p)
lgm <- function(y,p,trim=TRUE) {
  n <- nrow(y);
  k <- ncol(y);
  ly <- array(0,c(n,k*p));
  for (i in 1:p) {
    ly[(1+i):n,((i-1)*k+1):(i*k)] <- y[1:(n-i),];
  }
  ly <- ly[(1+trim*p):n,];
  return(as.matrix(ly));
}

# First differences
dif <- function(y,trim=TRUE) {
  dy <- y - lgm(y,1,0);
  dy <- dy[(1+trim):nrow(y),];
  return(as.matrix(dy));
}

# Detrending of (possibly multivariate) time series
detr <- function(y,dc,cT=1) {
  T <- nrow(y);
  dcc <- ceiling((dc+1)/2);
  z <- cbind(1,1:T);
  zc <- dif(z,0) + cT*lgm(z,1,0);
  yc <- dif(y,0) + cT*lgm(y,1,0);
  z <- z[,1:dcc];
  zc <- zc[,1:dcc];
  
  b <- ols(yc,zc);
  x <- y - ceiling(dc/2)*z%*%b;
  return(as.matrix(x));
}

# Eigendecomposition
eigdec <- function(x) {
  a <- eigen(x,symmetric=TRUE);
  sx <- a$vectors%*%sqrt(diag(a$values))%*%t(a$vectors);
}

# Translated from Gauss code of G. Rapuch & T. Roncalli (2001) - DefiniteCorrelation
pdm <- function(m,eps=1e-10) {
  ev <- eigen(m);
  va <- ev$values;
  ve <- ev$vectors;
  b <- va>eps;
  f <- sum(va-(1-b)*eps)/sum(b*va);
  va <- diag(f*(b*va)+(1-b)*eps);
  k <- ve%*%va%*%solve(ve);
  s <- sqrt(diag(k));
  k <- k/(s%*%t(s));
}

# (Square root of) Covariance matrix DWB
sqrtsigma <- function(k,h,T,met=chol,pdc=1,eps=1e-10) {
  ih <- outer(1:T,1:T,"-")/h;
  CM <- do.call(k,list(ih));
  if (identical(pdc,1)) {
    CM <- pdm(CM,eps);
  }
  S <- met(CM);
}

# Functions for "optimal TBB kernel" (self-convolution of w.trap), see Shao (2010, Remark 2.1)
# Trapezoid (w.trap)
w.trap <- function(x,c) {
  y <- (x/c)*(x>=0)*(x<c) + (x>=c)*(x<=1-c) + ((1-x)/c)*(x>1-c)*(x<=1);
}

# Integrand
f.w <- function(x,t,c) {
  y <- w.trap(x,c)*w.trap(x+abs(t),c);
}

# Self-convolution
self.conv <- function(t,c) {
  if (identical(t,0)) {
  	y <- unlist(integrate(f.w,-1,1,t,c)[1]);
  } else {
    y <- array(0,c(dim(t)));
    for (j in 1:ncol(t)) {
      for (i in 1:nrow(t)) {
        y[i,j] <- unlist(integrate(f.w,-1,1,t[i,j],c)[1]);
      }
    }
  }
  return(y);
}

# Bartlett kernel
bartlett <- function(x) {
  y <- (1-abs(x))*(abs(x)<=1);
}

# Gaussian kernel
gaussian <- function(x) {
  y <- dnorm(x);
}

# TBB kernel
kTBB <- function(t,c=0.43) {
  y <- self.conv(t,c)/self.conv(0,c);
}

# Parzen kernel
parzen <- function(x) {
  y <- (1 - 6*x^2 + 6*abs(x)^3)*(abs(x)<=1/2) + 2*((1-abs(x))^3)*(abs(x)>1/2)*(abs(x)<=1);
}

# Quadratic-spectral kernel
quadratic.spectral <- function(x) {
  y <- 25*(sin(6*pi*x/5)/(6*pi*x/5) - cos(6*pi*x/5))/(12*x^2*pi^2) + (abs(x)<=1e-10);
}

# Truncated kernel
truncated <- function(x){;
  y <- abs(x)<=1;
}

# Tukey-Hanning kernel
tukey.hanning <- function(x) {
  y <- (abs(x)<=1)*(1+cos(pi*x))/2;
}

# Nonparametric volatility estimation
npve <- function(u,k=gaussian,h=0.1) {
  r <- (1:nrow(u))/nrow(u);
  rh <- outer(r,r,"-")/h;
  kr <- do.call(k,list(rh));
  vm <- (kr%*%u^2)/rowSums(kr);
}

# ADF estimation for rescaling; can be used to modify RSIC - for details see Cavaliere et al. (2014)
adf.sc <- function(y,p) {
  dy <- dif(y,0);
  m <- cbind(lgm(y,1,0),lgm(dy,p+1,0));
  m <- as.matrix(m[,1:(1+p)]);
  m2 <- m[(2+p):nrow(y),];
  b <- ols(dy[(2+p):nrow(y)],m2);
  e <- dy-m%*%b;
}

# Rescaling for RSIC
rescale <- function(yd,k=gaussian,h=0.1,p=0) {
  u <- adf.sc(yd,p);
  yb <- dif(yd,0);
  shat <- sqrt(npve(u,k,h));
  ys <- as.matrix(filter(yb/shat,1,"r"));
}

# Akaike information criterion
AIC <- function(e,p,d,yl=0,r=0) {
  ic <- log(crossprod(e)/d) + 2*p/d;
}

BIC <- function(e,p,d,yl=0,r=0) {
  ic <- log(crossprod(e)/d) + log(d)*p/d;
}

MAIC <- function(e,p,d,yl,r) {
  t_p <- crossprod(yl)*r^2/(crossprod(e)/d);
  ic <- log(crossprod(e)/d) + 2*(p+t_p)/d;
}

MBIC <- function(e,p,d,yl,r) {
  t_p <- crossprod(yl)*r^2/(crossprod(e)/d);
  ic <- log(crossprod(e)/d) + log(d)*(p+t_p)/d;
}

# ADF for IC calculation
adf.ic <- function(y,p,q) {
  dy <- dif(y);
  m <- cbind(lgm(y,1),lgm(dy,p+1,0));
  m <- m[(1+q):nrow(dy),1:(1+p)];
  b <- ols(dy[(1+q):nrow(dy)],m);
  e <- dy[(1+q):nrow(dy)]-m%*%b;
  return(rbind(b[1],e))
}

# Lag length selection using information criteria in individual ADF regressions
ls.ic.adf <- function(ic,y,dc,p.max,p.min=0,c=1,rs=1,k=gaussian,h=0.1) {
  n <- nrow(y);
  d <- n - p.max;
  yd <- detr(y,dc,c);
  if (rs) {
    yd <- rescale(yd,k,h);
  }
  yl <- yd[(p.max+1):(n-1)];

  er <- adf.ic(yd,p.min,p.max);
  ic0 <- do.call(ic,list(er[2:nrow(er)],p.min,d,yl,er[1]));

  p.ic <- array(ic0,p.max-p.min+1);
  for (p in (p.min+1):p.max) {
    er <- adf.ic(yd,p,p.max);
    p.ic[p-p.min+1] = do.call(ic,list(er[2:nrow(er)],p,d,yl,er[1]));
  }
  return(which.min(p.ic)+p.min-1);
}

# Lag length selection for all N units
panellags <- function(ic,y,dc,p.max=-1,p.min=0,c=1,rs=1,k=gaussian,h=0.1) {
  N <- ncol(y);
  p <- array(0,N);
  if (identical(p.max,-1)) {
    p.max <- floor(12*(nrow(y)/100)^(1/4));
  }
  for (i in 1:N) {
    p[i] <- ls.ic.adf(ic,as.matrix(na.omit(y[,i])),dc,p.max,p.min,c,rs,k,h);
  }
  return(p);
}

# Bootstrap unit root process with BWB errors
BWB <- function(u,y0,bl,s,ar,sd) {
  x <- rnorm(ceiling(nrow(u)/round(bl)));
  xi <- rep(x,each=bl);
  ub <- u*array(xi[1:nrow(u)],dim(u));
  yb <- array(dim=dim(ub));
  for (i in 1:ncol(ub)) {
    yb[(1:nrow(ub))[is.na(ub[,i])==FALSE],i] <- filter(na.omit(ub[,i]),1,"r",init=y0[i]);
  }
  return(as.matrix(yb));
}

# Bootstrap unit root process with DWB errors
DWB <- function(u,y0,bl,s,ar,sd) {
  x <- rnorm(nrow(u));
  xi <- t(s)%*%x;
  ub <- u*array(xi,dim(u));
  yb <- array(dim=dim(ub));
  for (i in 1:ncol(ub)) {
    yb[(1:nrow(ub))[is.na(ub[,i])==FALSE],i] <- filter(na.omit(ub[,i]),1,"r",init=y0[i]);
  }
  return(as.matrix(yb));
}

# Bootstrap unit root process with AWB errors
AWB <- function(u,y0,bl,s,ar,sd) {
  x <- rnorm(nrow(u));
  xi <- filter(sqrt(1-ar^2)*x,ar,"r");
  ub <- u*array(xi,dim(u));
  yb <- array(dim=dim(ub));
  for (i in 1:ncol(ub)) {
    yb[(1:nrow(ub))[is.na(ub[,i])==FALSE],i] <- filter(na.omit(ub[,i]),1,"r",init=y0[i]);
  }
  return(as.matrix(yb));
}

# ADF for a single time series (used within adf.N)
adf.i <- function(y,p,pmax=max(p,1),T=nrow(y)) {
  dy0 = dif(y,0);
  dy = dy0[(2+p):T];
  mm = cbind(lgm(y,1,0),lgm(dy0,p+1,0));
  m = mm[(2+p):T,1:(1+p)];
  xi <- solve(crossprod(m));
  b <- xi%*%(crossprod(m,dy));
  e <- dy0-mm[,1:(1+p)]%*%b;
  s2 <- mean(e[(2+p):T]^2);
  Vb <- s2*xi;
  tt <- b[1]/sqrt(Vb[1,1]);
  tc <- T*b[1]/(1-colSums(b)+b[1]);
  to <- list(b[1],tt,tc,e);
}

# ADF for N time series
adf.N <- function(y,p,dc,c) {
  T <- nrow(y);
  N <- ncol(y);
  r <- array(dim=c(1,N));
  tc <- array(dim=c(1,N));
  tt <- array(dim=c(1,N));
  e <- array(dim=c(T,N));
  for (i in 1:N) {
    yd <- detr(as.matrix(na.omit(y[,i])),dc,c);
    toi <- adf.i(as.matrix(yd),p[i],pmax);
    r[i] <- toi[[1]];
    tc[i] <- toi[[2]];
    tt[i] <- toi[[3]];
    e[(1:T)[is.na(y[,i])==FALSE],i] <- toi[[4]];
  }
  return(list(r,tt,tc,e));
}

# Bootstrap part of the panel unit root test
boot.purt <- function(test,bs,y,tstat,ri,B,bl,S,ar,dc,cT,coeft,a,p,p.min,p.max,ic,llb,rs,ks,hs) {
  T <- nrow(y);
  N <- ncol(y);
  u <- array(dim=c(T,N));
  for (i in 1:N) {
    yd <- detr(as.matrix(na.omit(y[,i])),dc);
    u[(1:T)[is.na(y[,i])==FALSE],i] <- yd - lgm(yd,1,0)*ri[i];
  }
  tb <- array(0,B);
  for (i in 1:B) {
    yb <- do.call(bs,list(u,array(0,c(1,N)),bl,S,ar));
    if (llb) {
      pb <- panellags(ic,yb,dc,p.max,p.min,cT,rs,ks,hs);
    } else {
      pb <- p;
    }
    toi <- adf.N(yb,pb,dc,cT);
    tib <- coeft*toi[[3]] + (1-coeft)*toi[[2]];
    tb[i] <- do.call(test,list(tib));
  }
  ts <- sort(tb);
  cv <- ts[ceiling(a*B)];
  pv <- mean(tb<tstat);
  return(rbind(cv,pv));
}

# Panel unit root test
mwbpur <- function(y,test,bs,B,lvl,kappa,gls.dt,adf.coef,l.bwb=-1,l.dwb=-1,k.dwb=kTBB,gamma.awb=-1,p.min=0,p.max=-1,ic=MAIC,ls.boot=TRUE,rs=TRUE,k.rs=gaussian,h.rs=0.1,c.gls=c(7,13.5),out.scr=TRUE) {
  start.time <- proc.time();
  y <- as.matrix(y);
  T <- nrow(y);
  N <- ncol(y);
  dc <- kappa+1;
  cT <- (c.gls[ceiling((dc+1)/2)]/T)^gls.dt;
  if (identical(p.min,p.max)) {
    ls.boot <- FALSE;
    p <- array(p.min,N);
  } else {
    p <- panellags(ic,y,dc,p.max,p.min,cT,rs,k.rs,h.rs)
  }
  if (identical(l.bwb,-1)) {
    l.bwb <- round(1.75*T^(1/3));
  }
  if (identical(l.dwb,-1)) {
    l.dwb <- 1.75*T^(1/3);
  }
  if (identical(gamma.awb,-1)) {
    gamma.awb <- 0.01^(1.75*T^(1/3));
  }
  S <- sqrtsigma(k.dwb,l.dwb,T);
  
  nt <- length(test);
  nb <- length(bs);
  ts <- array(0,c(nt,1),dimnames=list(test));
  cv <- array(0,c(nt,nb),dimnames=list(test,bs));
  pv <- cv;
  toi <- adf.N(y,p,dc,cT);
  ri <- toi[[1]]+1;
  ti <- adf.coef*toi[[3]] + (1-adf.coef)*toi[[2]];
  for (i in 1:nt) {
    ts[i] <- do.call(test[i],list(ti));
    for (j in 1:nb) {
      bo <- boot.purt(test[i],bs[j],y,ts[i],ri,B,l.bwb,S,gamma.awb,dc,cT,adf.coef,lvl,p,p.min,p.max,ic,ls.boot,rs,k.rs,h.rs);
      cv[i,j] <- bo[1];
      pv[i,j] <- bo[2];
    }
  }
  el.time <- proc.time() - start.time;
  outp <- list(test.statistics=ts,critical.values=cv,p.values=pv,lag.lengths=p,running.time=el.time)
  if (out.scr) {
    MWB.output(outp,test,bs,B,lvl,kappa,gls.dt,adf.coef);
  }
  return(outp);
}